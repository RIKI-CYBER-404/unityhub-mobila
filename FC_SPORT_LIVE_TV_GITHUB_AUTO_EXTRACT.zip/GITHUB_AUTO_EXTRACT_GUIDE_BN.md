# FC SPORT LIVE TV — GitHub Auto Extract & Build

## Android phone থেকে ব্যবহার

1. এই ZIP Extract না করেও GitHub repository-তে এর ভেতরের সব ফাইল upload করুন (repository root-এ `gradlew`, `app/`, `.github/` থাকবে)।
2. ভবিষ্যতে আলাদা Android project ZIP build করতে চাইলে repository-তে `incoming` নামে folder বানিয়ে ZIP ফাইলটি সেখানে upload করুন।
3. GitHub-এ **Actions** → **Android Build (Auto Extract ZIP)** → **Run workflow** চাপুন।
4. Build শেষ হলে workflow run খুলে **Artifacts** থেকে `FC-SPORT-LIVE-TV-debug-APK` ডাউনলোড করুন।

## AAB
AAB তৈরি করতে GitHub repository → Settings → Secrets and variables → Actions-এ signing secrets যোগ করতে হবে:
- `UPLOAD_KEYSTORE_BASE64`
- `STORE_PASSWORD`
- `KEY_PASSWORD`

এই secrets ছাড়া workflow শুধু debug APK তৈরি করবে। AAB-এর জন্য release signing config-ও Gradle project-এ সঠিকভাবে থাকতে হবে।

## গুরুত্বপূর্ণ
`incoming/`-এ একবারে একটি project ZIP রাখুন। ZIP-এর ভেতরে Android Gradle project থাকতে হবে; `gradlew`, `settings.gradle` বা `settings.gradle.kts`, এবং `app/` ফোল্ডার থাকতে হবে।
