package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.SuperUnityHubApp
import com.example.ui.UnityHubViewModel
import com.example.ui.theme.UnityHubTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UnityHubTheme {
                val hubViewModel: UnityHubViewModel = viewModel()
                SuperUnityHubApp(viewModel = hubViewModel)
            }
        }
    }
}
