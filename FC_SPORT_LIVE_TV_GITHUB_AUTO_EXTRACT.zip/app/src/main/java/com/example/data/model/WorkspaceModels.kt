package com.example.data.model

import java.util.UUID

data class FileNode(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val extension: String = "",
    val children: MutableList<FileNode> = mutableListOf(),
    var isExpanded: Boolean = false,
    var content: String = ""
)

data class SceneGameObject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val tag: String = "Untagged",
    val layer: String = "Default",
    val isActive: Boolean = true,
    var posX: Float = 0f,
    var posY: Float = 0f,
    var posZ: Float = 0f,
    var rotX: Float = 0f,
    var rotY: Float = 0f,
    var rotZ: Float = 0f,
    var scaleX: Float = 1f,
    var scaleY: Float = 1f,
    var scaleZ: Float = 1f,
    val components: List<String> = listOf("Transform"),
    val children: List<SceneGameObject> = emptyList(),
    var isExpanded: Boolean = false
)

enum class EditorViewMode {
    CODE,
    CONTENT,
    PREVIEW
}

data class OpenTab(
    val id: String,
    val title: String,
    val filePath: String,
    val isScene: Boolean = false,
    var isDirty: Boolean = false
)

data class WorkspaceProject(
    val id: String,
    val name: String,
    val packageName: String = "com.example.unity",
    val path: String,
    val template: String,
    val editorVersion: String = "6000.0.32f1 (LTS)",
    val companyName: String = "hh.aa",
    val activePlatform: BuildPlatform = BuildPlatform.ANDROID,
    val gitBranch: String = "main",
    val rootFolder: FileNode,
    val sceneObjects: List<SceneGameObject>
)
