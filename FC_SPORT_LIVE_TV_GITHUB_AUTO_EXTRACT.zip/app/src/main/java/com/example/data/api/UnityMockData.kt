package com.example.data.api

import com.example.data.model.BuildPlatform
import com.example.data.model.EditorModule
import com.example.data.model.LicenseStatus
import com.example.data.model.LicenseType
import com.example.data.model.ReleaseChannel
import com.example.data.model.UnityEditorVersion
import com.example.data.model.UnityLicense
import com.example.data.model.UnityPackage
import com.example.data.model.UnityProject
import com.example.data.model.UnityTemplate
import com.example.data.model.UnityUser

object UnityMockData {

    fun createDemoUser(): UnityUser {
        return UnityUser(
            id = "usr_unity_73921",
            username = "alex.rivera",
            email = "alex.rivera@gamestudio.io",
            displayName = "Alex Rivera",
            avatarUrl = null,
            organizationName = "Starlight Interactive Studios",
            organizationId = "org_starlight_9921",
            role = "Lead Technical Director",
            accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.unity_sso_demo_token_authenticated",
            expiresAt = System.currentTimeMillis() + (7 * 86400000L),
            isDemoAccount = true
        )
    }

    fun getDefaultLicenses(): List<UnityLicense> {
        return listOf(
            UnityLicense(
                id = "lic_pro_001",
                type = LicenseType.PRO,
                status = LicenseStatus.ACTIVE,
                serialNumberMasked = "SC-PRO-9842-****-4982",
                fullSerial = "SC-PRO-9842-E91A-4982",
                activationDate = "2024-03-12",
                expirationDate = "2027-03-12",
                assignedTo = "Alex Rivera (Lead Technical Director)",
                machineBindingId = "MCH-DESKTOP-992A-4F",
                entitlements = listOf(
                    "Cloud Diagnostics & Crash Reporting",
                    "Havok Physics Multi-threaded Integration",
                    "Custom Splash Screen Removal",
                    "Unity Cloud Build Priority Queue",
                    "Source Code Inspection Access",
                    "Dedicated Enterprise Technical Support"
                ),
                seatsCount = 5
            ),
            UnityLicense(
                id = "lic_personal_002",
                type = LicenseType.PERSONAL,
                status = LicenseStatus.ACTIVE,
                serialNumberMasked = "FREE-PERSONAL-STUDENT-TIER",
                fullSerial = "FREE-PERSONAL-LICENSE-2026",
                activationDate = "2023-01-10",
                expirationDate = "Perpetual (Revenue < \$100k USD)",
                assignedTo = "Alex Rivera (Indie Projects)",
                machineBindingId = "MCH-MOBILE-CLIENT-02",
                entitlements = listOf(
                    "Core Unity Editor Engine",
                    "Standard Unity Package Manager",
                    "Community Forum Access",
                    "Visual Studio Tools for Unity"
                ),
                seatsCount = 1
            )
        )
    }

    fun getDefaultTemplates(): List<UnityTemplate> {
        return listOf(
            UnityTemplate(
                id = "tpl_urp_3d",
                title = "Universal 3D (URP)",
                renderPipeline = "URP",
                category = "3D",
                description = "Modern, high-performance 3D rendering pipeline optimized for cross-platform scalability across mobile, desktop, and VR consoles.",
                recommendedVersion = "6000.0.32f1 (LTS)",
                defaultPackages = listOf("Universal RP", "Input System", "TextMeshPro", "Mathematics")
            ),
            UnityTemplate(
                id = "tpl_hdrp_3d",
                title = "High Definition 3D (HDRP)",
                renderPipeline = "HDRP",
                category = "3D",
                description = "Photorealistic graphics pipeline featuring compute-based lighting, volumetric clouds, ray tracing, and physically based shaders.",
                recommendedVersion = "6000.0.32f1 (LTS)",
                defaultPackages = listOf("High Definition RP", "Shader Graph", "Visual Effect Graph", "Cinemachine")
            ),
            UnityTemplate(
                id = "tpl_2d_core",
                title = "2D Core",
                renderPipeline = "Standard",
                category = "2D",
                description = "Essential setup for 2D games with dedicated Sprite Editor, 2D Tilemap, 2D Physics engine, and 2D Animation tools.",
                recommendedVersion = "2022.3.52f1 (LTS)",
                defaultPackages = listOf("2D Sprite", "2D Tilemap", "2D Animation", "2D Pixel Perfect")
            ),
            UnityTemplate(
                id = "tpl_vr_core",
                title = "VR Core Experience",
                renderPipeline = "URP",
                category = "VR",
                description = "Pre-configured OpenXR stack with hands tracking, controller ray interactors, locomotion teleporters, and foveated rendering.",
                recommendedVersion = "6000.0.32f1 (LTS)",
                defaultPackages = listOf("XR Interaction Toolkit", "OpenXR Plugin", "Universal RP", "XR Core Utilities")
            ),
            UnityTemplate(
                id = "tpl_mobile_2d",
                title = "Mobile 2D Casual",
                renderPipeline = "URP",
                category = "Mobile",
                description = "Optimized for high-framerate mobile gaming with battery saving presets, touch controls, and lightweight sprite atlasing.",
                recommendedVersion = "6000.0.32f1 (LTS)",
                defaultPackages = listOf("Universal RP", "Input System", "In-App Purchasing", "Unity Ads")
            ),
            UnityTemplate(
                id = "tpl_3d_core",
                title = "3D Standard Core",
                renderPipeline = "Standard",
                category = "3D",
                description = "The classic built-in render pipeline template for straightforward 3D projects and legacy compatibility.",
                recommendedVersion = "2022.3.52f1 (LTS)",
                defaultPackages = listOf("Core RP", "TextMeshPro", "Input System")
            )
        )
    }

    fun getDefaultProjects(): List<UnityProject> {
        val packagesList1 = listOf(
            UnityPackage("pkg_1", "Universal RP", "17.0.3", "Universal Render Pipeline package"),
            UnityPackage("pkg_2", "Input System", "1.7.0", "New event-driven input handling system"),
            UnityPackage("pkg_3", "Cinemachine", "3.0.1", "Dynamic procedural smart cameras"),
            UnityPackage("pkg_4", "Addressables", "1.21.19", "Asynchronous asset management and bundles")
        )
        val packagesList2 = listOf(
            UnityPackage("pkg_5", "High Definition RP", "17.0.3", "High Definition Render Pipeline"),
            UnityPackage("pkg_6", "Visual Effect Graph", "17.0.3", "GPU-accelerated particle effects")
        )
        val packagesList3 = listOf(
            UnityPackage("pkg_7", "2D Tilemap Extras", "3.1.2", "Rule tiles and animated tile maps"),
            UnityPackage("pkg_8", "2D Animation", "9.0.4", "Bone rigging for 2D sprites")
        )

        return listOf(
            UnityProject(
                id = "proj_cyberpunk_odyssey",
                name = "Project Neon Horizon",
                template = "Universal 3D (URP)",
                category = "URP",
                editorVersion = "6000.0.32f1 (LTS)",
                targetPlatform = BuildPlatform.ANDROID,
                cloudStatus = "Synced",
                lastModified = "Just now",
                path = "/storage/emulated/0/UnityProjects/NeonHorizon",
                sizeMb = 1420,
                gitBranch = "feature/vulkan-mobile-opt",
                gitCommitHash = "9d41b02",
                packages = packagesList1
            ),
            UnityProject(
                id = "proj_sci_fi_corridor",
                name = "Aegis Station HDRP",
                template = "High Definition 3D (HDRP)",
                category = "HDRP",
                editorVersion = "6000.0.32f1 (LTS)",
                targetPlatform = BuildPlatform.WINDOWS,
                cloudStatus = "Synced",
                lastModified = "Yesterday at 18:42",
                path = "/storage/emulated/0/UnityProjects/AegisStation",
                sizeMb = 8900,
                gitBranch = "main",
                gitCommitHash = "4e18ac1",
                packages = packagesList2
            ),
            UnityProject(
                id = "proj_pixel_dungeon",
                name = "Shadow Realms 2D",
                template = "2D Core",
                category = "2D",
                editorVersion = "2022.3.52f1 (LTS)",
                targetPlatform = BuildPlatform.ANDROID,
                cloudStatus = "Needs Push",
                lastModified = "3 days ago",
                path = "/storage/emulated/0/UnityProjects/ShadowRealms2D",
                sizeMb = 480,
                gitBranch = "dev",
                gitCommitHash = "1b9a7c3",
                packages = packagesList3
            ),
            UnityProject(
                id = "proj_vr_flight",
                name = "Skyward VR Simulator",
                template = "VR Core Experience",
                category = "VR",
                editorVersion = "6000.0.32f1 (LTS)",
                targetPlatform = BuildPlatform.VISION_OS,
                cloudStatus = "Synced",
                lastModified = "Oct 24, 2026",
                path = "/storage/emulated/0/UnityProjects/SkywardVR",
                sizeMb = 2300,
                gitBranch = "main",
                gitCommitHash = "7f310cd",
                packages = packagesList1
            )
        )
    }

    fun getDefaultEditorVersions(): List<UnityEditorVersion> {
        val standardModules = listOf(
            EditorModule("mod_android", "Android Build Support", "Platform", 1450, true, "Compile APK & AAB targets with IL2CPP & Mono"),
            EditorModule("mod_android_tools", "Android SDK & NDK Tools", "Tools", 2100, true, "Google Android Command Line Tools, NDK 23b, Build-Tools"),
            EditorModule("mod_openjdk", "OpenJDK Java 17", "Tools", 350, true, "Embedded Temurin JDK runtime for Gradle packaging"),
            EditorModule("mod_ios", "iOS Build Support", "Platform", 1600, false, "Generate Xcode projects for iPhone and iPad targets"),
            EditorModule("mod_webgl", "WebGL Build Support", "Platform", 920, true, "Export HTML5 WebAssembly games for modern web browsers"),
            EditorModule("mod_windows", "Windows Build Support (IL2CPP)", "Platform", 1800, false, "High-performance native x86_64 Windows binaries"),
            EditorModule("mod_docs", "Documentation & Offline API", "Docs", 420, true, "Full local script reference and manual")
        )

        val uninstalledModules = standardModules.map { it.copy(isInstalled = false) }

        return listOf(
            UnityEditorVersion(
                version = "6000.0.32f1 (LTS)",
                cleanVersion = "6000.0.32f1",
                releaseDate = "October 2026",
                channel = ReleaseChannel.LTS,
                isInstalled = true,
                installPath = "/opt/unity/editors/6000.0.32f1",
                installedModules = standardModules.filter { it.isInstalled },
                availableModules = standardModules,
                releaseNotesSummary = "Unity 6 Long Term Support release featuring Resident Drawer GPU culling, Vulkan Ray Tracing for mobile, and Adaptive Probe Volumes.",
                downloadSizeGb = 4.1
            ),
            UnityEditorVersion(
                version = "2022.3.52f1 (LTS)",
                cleanVersion = "2022.3.52f1",
                releaseDate = "September 2026",
                channel = ReleaseChannel.LTS,
                isInstalled = true,
                installPath = "/opt/unity/editors/2022.3.52f1",
                installedModules = standardModules.filter { it.name.contains("Android") },
                availableModules = standardModules,
                releaseNotesSummary = "Rock-solid enterprise production stability release with backward compatibility for legacy rendering pipelines.",
                downloadSizeGb = 3.8
            ),
            UnityEditorVersion(
                version = "6000.1.0b4 (Beta)",
                cleanVersion = "6000.1.0b4",
                releaseDate = "October 28, 2026",
                channel = ReleaseChannel.BETA,
                isInstalled = false,
                installPath = null,
                installedModules = emptyList(),
                availableModules = uninstalledModules,
                releaseNotesSummary = "Next-gen tech preview introducing AI-driven sprite animation, WebGPU production pipeline, and real-time multiplayer mesh sync.",
                downloadSizeGb = 4.4
            ),
            UnityEditorVersion(
                version = "2021.3.45f1 (LTS)",
                cleanVersion = "2021.3.45f1",
                releaseDate = "July 2026",
                channel = ReleaseChannel.ARCHIVE,
                isInstalled = false,
                installPath = null,
                installedModules = emptyList(),
                availableModules = uninstalledModules,
                releaseNotesSummary = "Archived LTS release for ongoing live-ops projects maintaining 2021 LTS pipelines.",
                downloadSizeGb = 3.6
            )
        )
    }
}
