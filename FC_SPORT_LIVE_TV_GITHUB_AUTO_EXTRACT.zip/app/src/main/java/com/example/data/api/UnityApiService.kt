package com.example.data.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface UnityApiService {

    @FormUrlEncoded
    @POST("oauth/token")
    suspend fun exchangeToken(
        @Field("grant_type") grantType: String = "authorization_code",
        @Field("code") authCode: String,
        @Field("client_id") clientId: String,
        @Field("redirect_uri") redirectUri: String
    ): Response<Map<String, Any>>

    @GET("v1/users/me")
    suspend fun getCurrentUser(
        @Header("Authorization") authorization: String
    ): Response<Map<String, Any>>

    @GET("v1/licenses")
    suspend fun getLicenses(
        @Header("Authorization") authorization: String
    ): Response<List<Map<String, Any>>>

    @POST("v1/licenses/activate")
    suspend fun activateLicense(
        @Header("Authorization") authorization: String,
        @retrofit2.http.Body request: Map<String, String>
    ): Response<Map<String, Any>>

    companion object {
        private const val BASE_URL = "https://api.unity.com/"

        fun create(): UnityApiService {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(UnityApiService::class.java)
        }
    }
}
