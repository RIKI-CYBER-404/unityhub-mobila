package com.example.data.model

data class GeneratedCodeFile(
    val fileName: String,
    val filePath: String,
    val language: String, // "kotlin", "java", "gradle", "xml"
    var content: String
)

data class AndroidProjectExport(
    val projectName: String,
    val packageName: String,
    val targetLanguage: String, // "Kotlin" or "Java"
    val minSdk: Int = 24,
    val targetSdk: Int = 36,
    val isComposeEnabled: Boolean = true,
    val files: List<GeneratedCodeFile>
)

data class ApkBuildOptions(
    val buildType: String = "Debug (APK)", // "Debug (APK)", "Release (APK)", "Android App Bundle (.aab)"
    val targetArchitecture: String = "ARM64-v8a", // "ARM64-v8a", "armeabi-v7a", "Universal (Fat APK)"
    val graphicsApi: String = "Vulkan", // "Vulkan", "OpenGL ES 3.2"
    val isMinified: Boolean = false,
    val includeSymbols: Boolean = true,
    val selectedAppIcon: String = "3d_football" // "3d_football", "canyon_jet", "neon_cube", "cyber_hex"
)

data class DeviceInstallStatus(
    val isInstalled: Boolean = false,
    val apkName: String = "",
    val packageId: String = "",
    val versionName: String = "1.0.0",
    val installSizeMb: Float = 48.5f,
    val installedTimestamp: Long = 0L
)
