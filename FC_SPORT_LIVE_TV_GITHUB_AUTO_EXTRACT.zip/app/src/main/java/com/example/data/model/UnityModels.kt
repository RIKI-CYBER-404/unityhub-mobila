package com.example.data.model

data class UnityUser(
    val id: String,
    val username: String,
    val email: String,
    val displayName: String,
    val avatarUrl: String? = null,
    val organizationName: String = "Personal Workspace",
    val organizationId: String = "org-8492019",
    val role: String = "Owner",
    val accessToken: String = "",
    val tokenType: String = "Bearer",
    val expiresAt: Long = System.currentTimeMillis() + 86400000L,
    val isDemoAccount: Boolean = false
)

enum class LicenseType(val displayName: String) {
    PERSONAL("Unity Personal"),
    PLUS("Unity Plus"),
    PRO("Unity Pro"),
    ENTERPRISE("Unity Enterprise"),
    STUDENT("Unity Student")
}

enum class LicenseStatus(val label: String) {
    ACTIVE("Active"),
    EXPIRING_SOON("Expiring Soon"),
    EXPIRED("Expired"),
    RETURNED("Returned / Inactive")
}

data class UnityLicense(
    val id: String,
    val type: LicenseType,
    val status: LicenseStatus,
    val serialNumberMasked: String,
    val fullSerial: String? = null,
    val activationDate: String,
    val expirationDate: String,
    val assignedTo: String,
    val machineBindingId: String,
    val entitlements: List<String>,
    val seatsCount: Int = 1
)

enum class BuildPlatform(val displayName: String, val shortTag: String) {
    ANDROID("Android", "Android"),
    IOS("iOS", "iOS"),
    WINDOWS("Windows (x64)", "PC"),
    WEBGL("WebGL", "Web"),
    MACOS("macOS (Apple Silicon/Intel)", "Mac"),
    LINUX("Linux (x64)", "Linux"),
    VISION_OS("Apple visionOS", "VisionOS"),
    PS5("PlayStation 5", "PS5")
}

data class UnityPackage(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val isOfficial: Boolean = true
)

data class UnityProject(
    val id: String,
    val name: String,
    val template: String,
    val category: String, // "2D", "3D", "URP", "HDRP", "VR", "Mobile"
    val editorVersion: String,
    val targetPlatform: BuildPlatform = BuildPlatform.ANDROID,
    val cloudStatus: String = "Synced", // "Synced", "Building", "Local Only", "Needs Push"
    val lastModified: String,
    val path: String,
    val sizeMb: Int,
    val gitBranch: String = "main",
    val gitCommitHash: String = "7f3a29c",
    val packages: List<UnityPackage> = emptyList(),
    val cloudBuildRunning: Boolean = false,
    val cloudBuildProgress: Float = 0f
)

enum class ReleaseChannel(val displayName: String) {
    LTS("Official LTS"),
    TECH_STREAM("Tech Stream"),
    BETA("Beta / Pre-release"),
    ARCHIVE("Archive")
}

data class EditorModule(
    val id: String,
    val name: String,
    val category: String, // "Platform", "Tools", "Language", "Docs"
    val sizeMb: Int,
    val isInstalled: Boolean,
    val description: String
)

data class UnityEditorVersion(
    val version: String, // e.g. "6000.0.32f1 (LTS)"
    val cleanVersion: String, // e.g. "6000.0.32f1"
    val releaseDate: String,
    val channel: ReleaseChannel,
    val isInstalled: Boolean,
    val installPath: String? = null,
    val installedModules: List<EditorModule> = emptyList(),
    val availableModules: List<EditorModule> = emptyList(),
    val releaseNotesSummary: String = "",
    val downloadSizeGb: Double = 3.2,
    val isInstalling: Boolean = false,
    val installProgress: Float = 0f
)

data class UnityTemplate(
    val id: String,
    val title: String,
    val renderPipeline: String, // "Standard", "URP", "HDRP"
    val category: String, // "2D", "3D", "VR", "Mobile"
    val description: String,
    val recommendedVersion: String,
    val defaultPackages: List<String>
)

data class CloudBuildJob(
    val id: String,
    val projectName: String,
    val platform: BuildPlatform,
    val status: String, // "QUEUED", "COMPILING_SCRIPTS", "STRIPPING_IL2CPP", "PACKAGING_APK", "SUCCESS", "FAILED"
    val progress: Float,
    val logOutput: List<String>,
    val artifactUrl: String? = null,
    val startedAt: Long = System.currentTimeMillis()
)
