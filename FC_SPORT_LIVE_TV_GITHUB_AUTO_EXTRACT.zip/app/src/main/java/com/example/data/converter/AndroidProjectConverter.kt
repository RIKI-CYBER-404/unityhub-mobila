package com.example.data.converter

import com.example.data.model.AndroidProjectExport
import com.example.data.model.GeneratedCodeFile
import com.example.data.model.WorkspaceProject

object AndroidProjectConverter {

    fun convertToAndroidProject(
        project: WorkspaceProject,
        targetLanguage: String = "Kotlin"
    ): AndroidProjectExport {
        val cleanPkg = project.packageName.ifBlank { "com.example.unity" }
        val pkgPath = cleanPkg.replace(".", "/")
        val appName = project.name.replace(" ", "")

        val files = mutableListOf<GeneratedCodeFile>()

        // 1. Root settings.gradle.kts
        files.add(
            GeneratedCodeFile(
                fileName = "settings.gradle.kts",
                filePath = "settings.gradle.kts",
                language = "gradle",
                content = """
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${project.name}"
include(":app")
                """.trimIndent()
            )
        )

        // 2. Root build.gradle.kts
        files.add(
            GeneratedCodeFile(
                fileName = "build.gradle.kts (Project)",
                filePath = "build.gradle.kts",
                language = "gradle",
                content = """
plugins {
    id("com.android.application") version "8.7.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
                """.trimIndent()
            )
        )

        // 3. App module build.gradle.kts
        files.add(
            GeneratedCodeFile(
                fileName = "build.gradle.kts (Module: app)",
                filePath = "app/build.gradle.kts",
                language = "gradle",
                content = """
plugins {
    id("com.android.application")${if (targetLanguage == "Kotlin") "\n    id(\"org.jetbrains.kotlin.android\")" else ""}
}

android {
    namespace = "$cleanPkg"
    compileSdk = 36

    defaultConfig {
        applicationId = "$cleanPkg"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a"))
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }${if (targetLanguage == "Kotlin") """

    kotlinOptions {
        jvmTarget = "17"
    }""" else ""}

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    ${if (targetLanguage == "Kotlin") "implementation(\"androidx.core:core-ktx:1.13.1\")" else "implementation(\"androidx.core:core:1.13.1\")"}
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
}
                """.trimIndent()
            )
        )

        // 4. AndroidManifest.xml
        files.add(
            GeneratedCodeFile(
                fileName = "AndroidManifest.xml",
                filePath = "app/src/main/AndroidManifest.xml",
                language = "xml",
                content = """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-feature android:glEsVersion="0x00030002" android:required="true" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${project.name}"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.NoActionBar"
        android:hardwareAccelerated="true">

        <activity
            android:name=".$appName"
            android:exported="true"
            android:screenOrientation="portrait"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
                """.trimIndent()
            )
        )

        // 5. MainActivity (Kotlin or Java)
        if (targetLanguage == "Kotlin") {
            files.add(
                GeneratedCodeFile(
                    fileName = "$appName.kt",
                    filePath = "app/src/main/java/$pkgPath/$appName.kt",
                    language = "kotlin",
                    content = """
package $cleanPkg

import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

/**
 * Native Android Game Host generated from Unity project '${project.name}'.
 * Target Engine: ${project.editorVersion}
 * Active Platform: ${project.activePlatform.displayName}
 */
class $appName : AppCompatActivity() {

    private lateinit var gameView: UnityGameSurfaceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Initialize 3D Engine Surface View
        gameView = UnityGameSurfaceView(this).apply {
            loadScene("${project.template}")
        }
        setContentView(gameView)
    }

    override fun onResume() {
        super.onResume()
        gameView.resumeGameLoop()
    }

    override fun onPause() {
        super.onPause()
        gameView.pauseGameLoop()
    }
}
                    """.trimIndent()
                )
            )

            files.add(
                GeneratedCodeFile(
                    fileName = "UnityGameSurfaceView.kt",
                    filePath = "app/src/main/java/$pkgPath/UnityGameSurfaceView.kt",
                    language = "kotlin",
                    content = """
package $cleanPkg

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.SurfaceHolder
import android.view.SurfaceView

class UnityGameSurfaceView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    private var gameThread: Thread? = null
    private var isPlaying = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        holder.addCallback(this)
    }

    fun loadScene(sceneName: String) {
        // Initializes Unity scene assets and IL2CPP engine
    }

    fun resumeGameLoop() {
        isPlaying = true
        gameThread = Thread(this)
        gameThread?.start()
    }

    fun pauseGameLoop() {
        isPlaying = false
        try {
            gameThread?.join()
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    override fun run() {
        while (isPlaying) {
            if (!holder.surface.isValid) continue
            val canvas: Canvas = holder.lockCanvas() ?: continue
            try {
                // Render Game Frame (60 FPS Native Loop)
                canvas.drawColor(Color.parseColor("#12141C"))
                paint.color = Color.parseColor("#00E5FF")
                paint.textSize = 48f
                canvas.drawText("${project.name} Running (Vulkan)", 60f, 120f, paint)
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        resumeGameLoop()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pauseGameLoop()
    }
}
                    """.trimIndent()
                )
            )
        } else {
            files.add(
                GeneratedCodeFile(
                    fileName = "$appName.java",
                    filePath = "app/src/main/java/$pkgPath/$appName.java",
                    language = "java",
                    content = """
package $cleanPkg;

import android.os.Bundle;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Java Native Game Host converted from Unity project '${project.name}'.
 */
public class $appName extends AppCompatActivity {

    private UnityGameSurfaceView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        gameView = new UnityGameSurfaceView(this);
        gameView.loadScene("${project.template}");
        setContentView(gameView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.resumeGameLoop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (gameView != null) gameView.pauseGameLoop();
    }
}
                    """.trimIndent()
                )
            )

            files.add(
                GeneratedCodeFile(
                    fileName = "UnityGameSurfaceView.java",
                    filePath = "app/src/main/java/$pkgPath/UnityGameSurfaceView.java",
                    language = "java",
                    content = """
package $cleanPkg;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class UnityGameSurfaceView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    private Thread gameThread;
    private volatile boolean isPlaying = false;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public UnityGameSurfaceView(Context context) {
        super(context);
        getHolder().addCallback(this);
    }

    public void loadScene(String sceneName) {
        // Loads Unity IL2CPP scene assets
    }

    public void resumeGameLoop() {
        isPlaying = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void pauseGameLoop() {
        isPlaying = false;
        try {
            if (gameThread != null) {
                gameThread.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (isPlaying) {
            if (!getHolder().getSurface().isValid()) continue;
            Canvas canvas = getHolder().lockCanvas();
            if (canvas == null) continue;
            try {
                canvas.drawColor(Color.parseColor("#12141C"));
                paint.setColor(Color.parseColor("#00E5FF"));
                paint.setTextSize(48f);
                canvas.drawText("${project.name} Running (Vulkan)", 60f, 120f, paint);
            } finally {
                getHolder().unlockCanvasAndPost(canvas);
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        resumeGameLoop();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        pauseGameLoop();
    }
}
                    """.trimIndent()
                )
            )
        }

        return AndroidProjectExport(
            projectName = project.name,
            packageName = cleanPkg,
            targetLanguage = targetLanguage,
            files = files
        )
    }
}
