package com.example.data.repository

import com.example.data.model.BuildPlatform
import com.example.data.model.FileNode
import com.example.data.model.OpenTab
import com.example.data.model.SceneGameObject
import com.example.data.model.WorkspaceProject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class WorkspaceRepository {

    private val _projects = MutableStateFlow<List<WorkspaceProject>>(emptyList())
    val projects: StateFlow<List<WorkspaceProject>> = _projects.asStateFlow()

    private val _activeProject = MutableStateFlow<WorkspaceProject?>(null)
    val activeProject: StateFlow<WorkspaceProject?> = _activeProject.asStateFlow()

    private val _openTabs = MutableStateFlow<List<OpenTab>>(emptyList())
    val openTabs: StateFlow<List<OpenTab>> = _openTabs.asStateFlow()

    private val _selectedTabId = MutableStateFlow<String?>(null)
    val selectedTabId: StateFlow<String?> = _selectedTabId.asStateFlow()

    private val _activeFileContent = MutableStateFlow<String>("")
    val activeFileContent: StateFlow<String> = _activeFileContent.asStateFlow()

    init {
        val initialProjects = createDefaultProjects()
        _projects.value = initialProjects
        // Default active project
        _activeProject.value = initialProjects.firstOrNull()
    }

    fun openProject(project: WorkspaceProject) {
        _activeProject.value = project
        _openTabs.value = emptyList()
        _selectedTabId.value = null
        _activeFileContent.value = ""

        // Open default scene
        openFile("Assets/Scenes/Canyon Flight.unity", "Canyon Flight.unity", isScene = true)
    }

    fun closeActiveProject() {
        _activeProject.value = null
        _openTabs.value = emptyList()
        _selectedTabId.value = null
        _activeFileContent.value = ""
    }

    fun openFile(filePath: String, fileName: String, isScene: Boolean = false) {
        val existing = _openTabs.value.find { it.filePath == filePath }
        if (existing != null) {
            _selectedTabId.value = existing.id
            loadFileContent(filePath)
            return
        }

        val newTab = OpenTab(
            id = UUID.randomUUID().toString(),
            title = fileName,
            filePath = filePath,
            isScene = isScene
        )
        _openTabs.value = _openTabs.value + newTab
        _selectedTabId.value = newTab.id
        loadFileContent(filePath)
    }

    fun closeTab(tabId: String) {
        val remaining = _openTabs.value.filterNot { it.id == tabId }
        _openTabs.value = remaining
        if (_selectedTabId.value == tabId) {
            _selectedTabId.value = remaining.lastOrNull()?.id
            remaining.lastOrNull()?.let { loadFileContent(it.filePath) } ?: run {
                _activeFileContent.value = ""
            }
        }
    }

    fun selectTab(tabId: String) {
        _selectedTabId.value = tabId
        _openTabs.value.find { it.id == tabId }?.let {
            loadFileContent(it.filePath)
        }
    }

    fun updateActiveFileContent(newContent: String) {
        _activeFileContent.value = newContent
        val currentTab = _openTabs.value.find { it.id == _selectedTabId.value } ?: return
        val currentProj = _activeProject.value ?: return

        // Update file in virtual file tree
        findAndUpdateFile(currentProj.rootFolder, currentTab.filePath, newContent)
        _openTabs.value = _openTabs.value.map {
            if (it.id == currentTab.id) it.copy(isDirty = true) else it
        }
    }

    fun saveActiveFile() {
        val currentTab = _openTabs.value.find { it.id == _selectedTabId.value } ?: return
        _openTabs.value = _openTabs.value.map {
            if (it.id == currentTab.id) it.copy(isDirty = false) else it
        }
    }

    fun createNewFile(parentPath: String, fileName: String, isDirectory: Boolean) {
        val currentProj = _activeProject.value ?: return
        val extension = fileName.substringAfterLast(".", "")
        val defaultContent = when (extension) {
            "cs" -> """
using UnityEngine;

public class ${fileName.substringBefore(".")} : MonoBehaviour
{
    void Start()
    {
        Debug.Log("${fileName.substringBefore(".")} initialized!");
    }

    void Update()
    {
        // Add frame-by-frame gameplay updates
    }
}
            """.trimIndent()
            "unity" -> "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!29 &1\nOcclusionCullingSettings:\n  m_ObjectHideFlags: 0\n"
            else -> "// File created in Super Unity Hub"
        }

        val newNode = FileNode(
            name = fileName,
            path = if (parentPath.isEmpty()) fileName else "$parentPath/$fileName",
            isDirectory = isDirectory,
            extension = extension,
            content = defaultContent
        )

        addNodeToTree(currentProj.rootFolder, parentPath, newNode)
        _activeProject.value = currentProj.copy()

        if (!isDirectory) {
            openFile(newNode.path, newNode.name, isScene = extension == "unity")
        }
    }

    fun createProject(
        name: String,
        packageName: String,
        location: String,
        templateTitle: String
    ): WorkspaceProject {
        val newProj = WorkspaceProject(
            id = "proj_${System.currentTimeMillis()}",
            name = name.trim(),
            packageName = packageName.trim().ifBlank { "com.example.unity" },
            path = if (location.isNotBlank()) "$location/${name.trim()}" else "/data/user/0/com.m4coding.superunity/files/Workspace/${name.trim()}",
            template = templateTitle,
            companyName = "hh.aa",
            activePlatform = BuildPlatform.ANDROID,
            gitBranch = "main",
            rootFolder = createTemplateFileTree(templateTitle),
            sceneObjects = createDefaultSceneObjects()
        )

        val updated = _projects.value.toMutableList()
        updated.add(0, newProj)
        _projects.value = updated
        openProject(newProj)
        return newProj
    }

    fun updateProjectPlatform(platform: BuildPlatform) {
        val current = _activeProject.value ?: return
        val updated = current.copy(activePlatform = platform)
        _activeProject.value = updated
        _projects.value = _projects.value.map { if (it.id == updated.id) updated else it }
    }

    fun updateCompanyName(name: String) {
        val current = _activeProject.value ?: return
        val updated = current.copy(companyName = name)
        _activeProject.value = updated
        _projects.value = _projects.value.map { if (it.id == updated.id) updated else it }
    }

    private fun loadFileContent(filePath: String) {
        val currentProj = _activeProject.value ?: return
        val node = findFile(currentProj.rootFolder, filePath)
        _activeFileContent.value = node?.content ?: "// Content unavailable for $filePath"
    }

    private fun findFile(node: FileNode, path: String): FileNode? {
        if (node.path == path) return node
        for (child in node.children) {
            val found = findFile(child, path)
            if (found != null) return found
        }
        return null
    }

    private fun findAndUpdateFile(node: FileNode, path: String, content: String): Boolean {
        if (node.path == path) {
            node.content = content
            return true
        }
        for (child in node.children) {
            if (findAndUpdateFile(child, path, content)) return true
        }
        return false
    }

    private fun addNodeToTree(node: FileNode, targetParentPath: String, newNode: FileNode): Boolean {
        if (node.path == targetParentPath || (targetParentPath.isEmpty() && node.name == "Assets")) {
            node.children.add(newNode)
            return true
        }
        for (child in node.children) {
            if (addNodeToTree(child, targetParentPath, newNode)) return true
        }
        return false
    }

    private fun createDefaultProjects(): List<WorkspaceProject> {
        val canyonProj = WorkspaceProject(
            id = "proj_canyon_flight",
            name = "Canyon Flight Starter",
            packageName = "com.m4coding.canyonflight",
            path = "/data/user/0/com.m4coding.superunity/files/Workspace/CanyonFlight",
            template = "Canyon Flight Starter",
            companyName = "hh.aa",
            activePlatform = BuildPlatform.ANDROID,
            gitBranch = "main",
            rootFolder = createTemplateFileTree("Canyon Flight Starter"),
            sceneObjects = createDefaultSceneObjects()
        )

        val footballProj = WorkspaceProject(
            id = "proj_rising_xi",
            name = "RisingXI_Football_Prototype",
            packageName = "com.m4coding.risingxi",
            path = "/data/user/0/com.m4coding.superunity/files/Workspace/RisingXI_Football_Prototype",
            template = "Rising XI 3D Football",
            companyName = "hh.aa",
            activePlatform = BuildPlatform.ANDROID,
            gitBranch = "dev/vulkan-opt",
            rootFolder = createTemplateFileTree("Rising XI 3D Football"),
            sceneObjects = createFootballSceneObjects()
        )

        return listOf(canyonProj, footballProj)
    }

    private fun createTemplateFileTree(templateTitle: String): FileNode {
        val assets = FileNode(name = "Assets", path = "Assets", isDirectory = true, isExpanded = true)

        val fonts = FileNode(name = "Fonts", path = "Assets/Fonts", isDirectory = true)
        val materials = FileNode(name = "Materials", path = "Assets/Materials", isDirectory = true)
        val plugins = FileNode(name = "Plugins", path = "Assets/Plugins", isDirectory = true)
        val prefabs = FileNode(name = "Prefabs", path = "Assets/Prefabs", isDirectory = true)
        val resources = FileNode(name = "Resources", path = "Assets/Resources", isDirectory = true)

        val scenes = FileNode(name = "Scenes", path = "Assets/Scenes", isDirectory = true, isExpanded = true)
        val mainScene = FileNode(
            name = "Canyon Flight.unity",
            path = "Assets/Scenes/Canyon Flight.unity",
            isDirectory = false,
            extension = "unity",
            content = "// Unity Scene YAML v2026.1\nScene: Canyon Flight\nActive Camera: Main Camera\nLighting: Dynamic Sun\n"
        )
        scenes.children.add(mainScene)

        val scripts = FileNode(name = "Scripts", path = "Assets/Scripts", isDirectory = true, isExpanded = true)

        scripts.children.addAll(
            listOf(
                FileNode(
                    name = "EnergyGate.cs",
                    path = "Assets/Scripts/EnergyGate.cs",
                    isDirectory = false,
                    extension = "cs",
                    content = """
using UnityEngine;

public class EnergyGate : MonoBehaviour
{
    [SerializeField] private float speed = 5.0f;
    [SerializeField] private int scoreValue = 10;
    private bool collected = false;

    void Update()
    {
        transform.Translate(Vector3.left * speed * Time.deltaTime);
        if (transform.position.x < -15f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") && !collected)
        {
            collected = true;
            FlightSession.Instance.AddScore(scoreValue);
            Destroy(gameObject, 0.1f);
        }
    }
}
                    """.trimIndent()
                ),
                FileNode(
                    name = "FlightSession.cs",
                    path = "Assets/Scripts/FlightSession.cs",
                    isDirectory = false,
                    extension = "cs",
                    content = """
using UnityEngine;
using UnityEngine.UI;

public class FlightSession : MonoBehaviour
{
    public static FlightSession Instance { get; private set; }

    public int currentScore = 0;
    public bool isGameOver = false;

    void Awake()
    {
        Instance = this;
    }

    public void AddScore(int amount)
    {
        currentScore += amount;
    }

    public void TriggerGameOver()
    {
        isGameOver = true;
        Debug.Log("GAME OVER! Final Score: " + currentScore);
    }
}
                    """.trimIndent()
                ),
                FileNode(
                    name = "GateSpawner.cs",
                    path = "Assets/Scripts/GateSpawner.cs",
                    isDirectory = false,
                    extension = "cs",
                    content = """
using UnityEngine;

public class GateSpawner : MonoBehaviour
{
    public GameObject gatePrefab;
    public float spawnInterval = 1.8f;
    private float timer = 0f;

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= spawnInterval)
        {
            timer = 0f;
            float randomY = Random.Range(-3.5f, 3.5f);
            Instantiate(gatePrefab, new Vector3(12f, randomY, 0f), Quaternion.identity);
        }
    }
}
                    """.trimIndent()
                ),
                FileNode(
                    name = "MobileLayout.cs",
                    path = "Assets/Scripts/MobileLayout.cs",
                    isDirectory = false,
                    extension = "cs",
                    content = """
using UnityEngine;

public class MobileLayout : MonoBehaviour
{
    void Start()
    {
        Screen.orientation = ScreenOrientation.Portrait;
        Application.targetFrameRate = 60;
    }
}
                    """.trimIndent()
                ),
                FileNode(
                    name = "Parallax.cs",
                    path = "Assets/Scripts/Parallax.cs",
                    isDirectory = false,
                    extension = "cs",
                    content = """
using UnityEngine;

public class Parallax : MonoBehaviour
{
    public float parallaxSpeed = 0.5f;
    private Material mat;

    void Start()
    {
        mat = GetComponent<Renderer>().material;
    }

    void Update()
    {
        mat.mainTextureOffset += new Vector2(parallaxSpeed * Time.deltaTime, 0);
    }
}
                    """.trimIndent()
                ),
                FileNode(
                    name = "RocketController.cs",
                    path = "Assets/Scripts/RocketController.cs",
                    isDirectory = false,
                    extension = "cs",
                    content = """
using UnityEngine;

public class RocketController : MonoBehaviour
{
    [SerializeField] private float thrustPower = 6.5f;
    [SerializeField] private float tiltMultiplier = 20f;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began))
        {
            rb.linearVelocity = Vector2.up * thrustPower;
        }

        float angle = Mathf.Clamp(rb.linearVelocity.y * tiltMultiplier, -35f, 35f);
        transform.rotation = Quaternion.Euler(0, 0, angle);
    }
}
                    """.trimIndent()
                )
            )
        )

        val sprites = FileNode(name = "Sprites", path = "Assets/Sprites", isDirectory = true)
        val packages = FileNode(name = "Packages", path = "Packages", isDirectory = true)

        assets.children.addAll(listOf(fonts, materials, plugins, prefabs, resources, scenes, scripts, sprites))

        val root = FileNode(name = "ProjectRoot", path = "", isDirectory = true, isExpanded = true)
        root.children.addAll(listOf(assets, packages))
        return root
    }

    private fun createDefaultSceneObjects(): List<SceneGameObject> {
        return listOf(
            SceneGameObject(name = "FlightSession", components = listOf("Transform", "FlightSession (Script)")),
            SceneGameObject(name = "CanyonBackdrop", components = listOf("Transform", "MeshRenderer", "Parallax (Script)")),
            SceneGameObject(name = "LandingStrip", components = listOf("Transform", "BoxCollider2D")),
            SceneGameObject(name = "Rocket", components = listOf("Transform", "Rigidbody2D", "CircleCollider2D", "RocketController (Script)")),
            SceneGameObject(name = "GateSpawner", components = listOf("Transform", "GateSpawner (Script)")),
            SceneGameObject(name = "Main Camera", components = listOf("Transform", "Camera", "AudioListener")),
            SceneGameObject(name = "Canvas", components = listOf("Transform", "Canvas", "CanvasScaler", "GraphicRaycaster")),
            SceneGameObject(name = "EventSystem", components = listOf("Transform", "EventSystem", "StandaloneInputModule"))
        )
    }

    private fun createFootballSceneObjects(): List<SceneGameObject> {
        return listOf(
            SceneGameObject(name = "MatchController", components = listOf("Transform", "MatchManager (Script)")),
            SceneGameObject(name = "Stadium_Arena", components = listOf("Transform", "MeshRenderer", "MeshCollider")),
            SceneGameObject(name = "Player_Forward", components = listOf("Transform", "Rigidbody", "CapsuleCollider", "PlayerMovement (Script)")),
            SceneGameObject(name = "Goalkeeper_AI", components = listOf("Transform", "NavMeshAgent", "GoalkeeperController (Script)")),
            SceneGameObject(name = "MatchBall", components = listOf("Transform", "SphereCollider", "PhysicsMaterial")),
            SceneGameObject(name = "Main Camera", components = listOf("Transform", "Camera", "CinemachineVirtualCamera")),
            SceneGameObject(name = "Canvas_Scoreboard", components = listOf("Transform", "Canvas", "Text"))
        )
    }
}
