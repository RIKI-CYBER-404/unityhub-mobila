package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LicenseStatus
import com.example.data.model.LicenseType
import com.example.data.model.UnityLicense
import com.example.ui.theme.UnityAmber
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityElectricBlue
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityRed
import com.example.ui.theme.UnityTeal
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UnityLicenseCard(
    license: UnityLicense,
    onReturnLicense: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showReturnConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("license_card_${license.id}"),
        colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (license.status == LicenseStatus.ACTIVE) UnityCyan.copy(alpha = 0.4f) else UnityCardBorder
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Type & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when (license.type) {
                                    LicenseType.PRO -> Color(0xFF004D5A)
                                    LicenseType.ENTERPRISE -> Color(0xFF381E72)
                                    LicenseType.STUDENT -> Color(0xFF1B4D3E)
                                    else -> Color(0xFF2E323D)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "License",
                            tint = UnityCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = license.type.displayName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                        Text(
                            text = "Assigned to ${license.assignedTo}",
                            fontSize = 12.sp,
                            color = UnityTextSecondary
                        )
                    }
                }

                // Status Badge
                Surface(
                    color = when (license.status) {
                        LicenseStatus.ACTIVE -> Color(0xFF163828)
                        LicenseStatus.EXPIRING_SOON -> Color(0xFF3D2A00)
                        else -> Color(0xFF332020)
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    when (license.status) {
                                        LicenseStatus.ACTIVE -> UnityGreen
                                        LicenseStatus.EXPIRING_SOON -> UnityAmber
                                        else -> UnityRed
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = license.status.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (license.status) {
                                LicenseStatus.ACTIVE -> UnityGreen
                                LicenseStatus.EXPIRING_SOON -> UnityAmber
                                else -> UnityRed
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Serial Number Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF1B1D23),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "Serial Key",
                            tint = UnityCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = license.serialNumberMasked,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            color = UnityTextPrimary
                        )
                    }

                    Text(
                        text = "${license.seatsCount} seat${if (license.seatsCount > 1) "s" else ""}",
                        fontSize = 11.sp,
                        color = UnityTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Details metadata
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "Expires", fontSize = 11.sp, color = UnityTextMuted)
                    Text(text = license.expirationDate, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = UnityTextPrimary)
                }
                Column {
                    Text(text = "Machine Binding", fontSize = 11.sp, color = UnityTextMuted)
                    Text(text = license.machineBindingId, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = UnityTextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Entitlements Section
            Text(
                text = "ENTITLEMENTS & SERVICES",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = UnityCyan,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                license.entitlements.forEach { entitlement ->
                    Surface(
                        color = Color(0xFF1E2129),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = UnityTeal,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = entitlement,
                                fontSize = 10.sp,
                                color = UnityTextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Row: Return / Deactivate
            if (license.status == LicenseStatus.ACTIVE) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = { showReturnConfirm = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = UnityRed),
                        border = BorderStroke(1.dp, UnityRed.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_return_license_${license.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "Return",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Return License Seat", fontSize = 12.sp)
                    }
                }
            }
        }
    }

    if (showReturnConfirm) {
        AlertDialog(
            onDismissRequest = { showReturnConfirm = false },
            containerColor = UnityCardBackground,
            title = {
                Text(text = "Return Unity License?", color = UnityTextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Returning this license will unbind it from this Android device and return the seat to your Unity organization license pool. You can re-activate it at any time.",
                    color = UnityTextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showReturnConfirm = false
                        onReturnLicense()
                    }
                ) {
                    Text(text = "Return Seat", color = UnityRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReturnConfirm = false }) {
                    Text(text = "Cancel", color = UnityTextSecondary)
                }
            }
        )
    }
}
