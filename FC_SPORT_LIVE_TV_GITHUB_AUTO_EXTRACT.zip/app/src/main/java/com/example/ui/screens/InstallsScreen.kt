package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ReleaseChannel
import com.example.data.model.UnityEditorVersion
import com.example.ui.components.UnityInstallCard
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityDarkBackground
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@Composable
fun InstallsScreen(
    editorVersions: List<UnityEditorVersion>,
    onAddModules: (UnityEditorVersion) -> Unit,
    onInstall: (String) -> Unit,
    onLocateEditorClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedChannelTab by remember { mutableIntStateOf(0) } // 0: Installed, 1: Official LTS, 2: Pre-releases, 3: Archive

    val filteredList = when (selectedChannelTab) {
        0 -> editorVersions.filter { it.isInstalled }
        1 -> editorVersions.filter { it.channel == ReleaseChannel.LTS }
        2 -> editorVersions.filter { it.channel == ReleaseChannel.BETA || it.channel == ReleaseChannel.TECH_STREAM }
        3 -> editorVersions.filter { it.channel == ReleaseChannel.ARCHIVE }
        else -> editorVersions
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UnityDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("installs_screen")
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Header Title & Locate Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Unity Editor Installs",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = UnityTextPrimary
                )
                Text(
                    text = "Manage versions & target platform modules",
                    fontSize = 12.sp,
                    color = UnityTextSecondary
                )
            }

            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onLocateEditorClick() }
                    .testTag("btn_locate_editor"),
                color = Color(0xFF23252E),
                border = BorderStroke(1.dp, UnityCardBorder),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = "Locate",
                        tint = UnityCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Locate",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = UnityCyan
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Row: Installed / Official LTS / Pre-releases / Archive
        TabRow(
            selectedTabIndex = selectedChannelTab,
            containerColor = Color(0xFF1B1D23),
            contentColor = UnityCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedChannelTab]),
                    color = UnityCyan
                )
            }
        ) {
            listOf("Installed", "Official Releases", "Pre-releases", "Archive").forEachIndexed { idx, title ->
                Tab(
                    selected = selectedChannelTab == idx,
                    onClick = { selectedChannelTab = idx },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedChannelTab == idx) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(0.85f),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No Editors Found",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Switch to 'Official Releases' tab to install Unity LTS or locate an existing binary.",
                            fontSize = 12.sp,
                            color = UnityTextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredList, key = { it.cleanVersion }) { editor ->
                    UnityInstallCard(
                        editor = editor,
                        onAddModulesClick = { onAddModules(editor) },
                        onInstallClick = { onInstall(editor.cleanVersion) },
                        onLocateClick = onLocateEditorClick
                    )
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}
