package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BuildPlatform
import com.example.data.model.UnityProject
import com.example.ui.theme.UnityAmber
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityElectricBlue
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityRed
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UnityProjectCard(
    project: UnityProject,
    onProjectClick: () -> Unit,
    onLaunchClick: () -> Unit,
    onCloudBuildClick: () -> Unit,
    onSwitchPlatform: (BuildPlatform) -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onProjectClick() }
            .testTag("project_card_${project.id}"),
        colors = CardDefaults.cardColors(
            containerColor = UnityCardBackground
        ),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, UnityCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            // Header Row: Title + Status + Overflow Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when (project.category) {
                                    "URP" -> Color(0xFF004D5A)
                                    "HDRP" -> Color(0xFF381E72)
                                    "2D" -> Color(0xFF1B4D3E)
                                    "VR" -> Color(0xFF5A2A00)
                                    else -> Color(0xFF2E323D)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = project.category.take(3),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = project.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${project.template} • ${project.sizeMb} MB",
                            fontSize = 12.sp,
                            color = UnityTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Cloud Status Pill
                Surface(
                    color = when (project.cloudStatus) {
                        "Synced" -> Color(0xFF163828)
                        "Building..." -> Color(0xFF3D2A00)
                        else -> Color(0xFF2E313C)
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    when (project.cloudStatus) {
                                        "Synced" -> UnityGreen
                                        "Building..." -> UnityAmber
                                        else -> UnityCyan
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = project.cloudStatus,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = when (project.cloudStatus) {
                                "Synced" -> UnityGreen
                                "Building..." -> UnityAmber
                                else -> UnityCyan
                            }
                        )
                    }
                }

                // Overflow Menu
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Project actions",
                            tint = UnityTextSecondary
                        )
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        modifier = Modifier.background(UnityCardBackground)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Project Details & Settings", color = UnityTextPrimary) },
                            onClick = {
                                menuExpanded = false
                                onProjectClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Trigger Cloud Build", color = UnityCyan) },
                            onClick = {
                                menuExpanded = false
                                onCloudBuildClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete from Hub", color = UnityRed) },
                            onClick = {
                                menuExpanded = false
                                onDeleteClick()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata Tags Row
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Editor Version Tag
                Surface(
                    color = Color(0xFF1E2026),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = project.editorVersion,
                        fontSize = 11.sp,
                        color = UnityCyan,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                // Target Platform Tag
                Surface(
                    color = Color(0xFF1E2026),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = project.targetPlatform.displayName,
                        fontSize = 11.sp,
                        color = UnityElectricBlue,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                // Git Branch Tag
                Surface(
                    color = Color(0xFF1E2026),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "git: ${project.gitBranch} (${project.gitCommitHash})",
                        fontSize = 11.sp,
                        color = UnityTextSecondary,
                        fontWeight = FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Path & Quick Actions Bottom Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Folder,
                        contentDescription = "Project Directory",
                        tint = UnityTextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Modified ${project.lastModified}",
                        fontSize = 11.sp,
                        color = UnityTextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Cloud Build Quick Button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onCloudBuildClick() }
                            .testTag("btn_build_${project.id}"),
                        color = Color(0xFF222B38),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = "Cloud Build",
                                tint = UnityCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Build",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = UnityCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Open / Launch Button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onLaunchClick() }
                            .testTag("btn_launch_${project.id}"),
                        color = UnityCyan,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Launch Unity Editor",
                                tint = Color(0xFF00363D),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Open",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00363D)
                            )
                        }
                    }
                }
            }
        }
    }
}
