package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.converter.AndroidProjectConverter
import com.example.data.model.AndroidProjectExport
import com.example.data.model.DeviceInstallStatus
import com.example.data.model.WorkspaceProject
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun BuildAndInstallDialog(
    project: WorkspaceProject,
    onDismiss: () -> Unit,
    onRunInGamePreview: () -> Unit = {},
    onExportComplete: (String) -> Unit = {}
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Build & Install, 1: Java/Kotlin Converter
    var buildType by remember { mutableStateOf("Debug (APK)") }
    var targetArch by remember { mutableStateOf("ARM64-v8a") }
    var graphicsApi by remember { mutableStateOf("Vulkan") }
    var selectedIcon by remember { mutableStateOf("3d_football") }

    var isBuilding by remember { mutableStateOf(false) }
    var buildProgress by remember { mutableFloatStateOf(0f) }
    var buildStepText by remember { mutableStateOf("") }
    var buildLogs = remember { mutableStateListOf<String>() }

    var installStatus by remember { mutableStateOf(DeviceInstallStatus()) }
    var isInstallingOnDevice by remember { mutableStateOf(false) }

    // Converter state
    var targetLang by remember { mutableStateOf("Kotlin") }
    var convertedProject by remember {
        mutableStateOf(AndroidProjectConverter.convertToAndroidProject(project, targetLang))
    }
    var selectedFileIndex by remember { mutableIntStateOf(0) }

    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .testTag("dialog_build_and_install"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161822)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFF2E3246))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Android, contentDescription = null, tint = Color(0xFF00E676))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Android Build, Run & Install", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${project.name} (${project.packageName})", fontSize = 11.sp, color = Color(0xFF868B9F))
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs: Build & Install vs Java/Kotlin Gradle Converter
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFF1E212F),
                    contentColor = Color(0xFF9E86FF),
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = Color(0xFF9E86FF)
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Build & Install APK", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Java / Kotlin Gradle", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (selectedTab == 0) {
                    // TAB 0: BUILD & INSTALL ON DEVICE
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Icon Selector
                        Text("APP LAUNCHER ICON", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9E86FF))
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf(
                                "3d_football" to ("⚽" to "Soccer 3D"),
                                "canyon_jet" to ("🚀" to "Jet 3D"),
                                "neon_cube" to ("🧊" to "Unity Hub"),
                                "cyber_hex" to ("🔮" to "Cyber"),
                                "retro_arcade" to ("🕹️" to "Arcade")
                            ).forEach { (id, pair) ->
                                val isSel = selectedIcon == id
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { selectedIcon = id },
                                    color = if (isSel) Color(0xFF38325E) else Color(0xFF222534),
                                    border = BorderStroke(1.dp, if (isSel) Color(0xFF9E86FF) else Color(0xFF2A2D3E)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(pair.first, fontSize = 20.sp)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(pair.second, fontSize = 9.sp, color = if (isSel) Color.White else Color(0xFF868B9F))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Build Configuration Options
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Target Arch
                            Column(modifier = Modifier.weight(1f)) {
                                Text("ARCHITECTURE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9E86FF))
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            targetArch = if (targetArch == "ARM64-v8a") "armeabi-v7a" else "ARM64-v8a"
                                        },
                                    color = Color(0xFF222534),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(targetArch, fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(8.dp))
                                }
                            }

                            // Graphics API
                            Column(modifier = Modifier.weight(1f)) {
                                Text("GRAPHICS API", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9E86FF))
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            graphicsApi = if (graphicsApi == "Vulkan") "OpenGL ES 3.2" else "Vulkan"
                                        },
                                    color = Color(0xFF222534),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(graphicsApi, fontSize = 11.sp, color = Color(0xFF00E5FF), modifier = Modifier.padding(8.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Device Installation Banner
                        if (installStatus.isInstalled) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = Color(0xFF132A1F),
                                border = BorderStroke(1.dp, Color(0xFF00E676)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF00E676), modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("App Installed on Android Phone!", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text("${project.packageName} • v1.0.0 (${installStatus.installSizeMb} MB)", fontSize = 11.sp, color = Color(0xFF8CD6AF))
                                    }
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable {
                                                onDismiss()
                                                onRunInGamePreview()
                                            },
                                        color = Color(0xFF00E676),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("Open", color = Color(0xFF00371B), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        // Build Progress / Logs Console
                        if (isBuilding || buildProgress > 0f) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(buildStepText, fontSize = 11.sp, color = Color(0xFF00E5FF))
                                    Text("${(buildProgress * 100).toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9E86FF))
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { buildProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = Color(0xFF00E5FF),
                                    trackColor = Color(0xFF222534)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(120.dp),
                                    color = Color(0xFF0D0E14),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    LazyColumn(modifier = Modifier.padding(8.dp)) {
                                        items(buildLogs) { log ->
                                            Text(
                                                text = log,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = if (log.contains("[Success]")) Color(0xFF00E676) else Color(0xFFC0C4D6)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        // Action Buttons: Build APK, Run in Simulator, Install on Device
                        Button(
                            onClick = {
                                isBuilding = true
                                buildProgress = 0.05f
                                buildLogs.clear()
                                buildLogs.add("[Unity 6000.0] Initializing APK build for ${project.name}...")

                                scope.launch {
                                    delay(400)
                                    buildProgress = 0.25f
                                    buildStepText = "Compiling C# scripts to Assembly-CSharp.dll..."
                                    buildLogs.add("[Roslyn] Compilation finished with 0 errors, 0 warnings.")

                                    delay(500)
                                    buildProgress = 0.50f
                                    buildStepText = "IL2CPP transpiling bytecodes to native $targetArch C++..."
                                    buildLogs.add("[IL2CPP] Native symbols stripped for size optimization.")

                                    delay(500)
                                    buildProgress = 0.75f
                                    buildStepText = "Android NDK compiling native libunity.so ($graphicsApi)..."
                                    buildLogs.add("[NDK] Linked Vulkan renderer pipeline.")

                                    delay(500)
                                    buildProgress = 0.95f
                                    buildStepText = "Packaging resources with AAPT2 and apksigner..."
                                    buildLogs.add("[Gradle] Built release APK: ${project.name}_v1.0.apk (48.5 MB)")

                                    delay(400)
                                    buildProgress = 1.0f
                                    isBuilding = false
                                    buildStepText = "Build Succeeded!"
                                    buildLogs.add("[Success] APK signed and ready to run or install.")

                                    installStatus = DeviceInstallStatus(
                                        isInstalled = true,
                                        apkName = "${project.name}.apk",
                                        packageId = project.packageName,
                                        versionName = "1.0.0",
                                        installSizeMb = 48.5f,
                                        installedTimestamp = System.currentTimeMillis()
                                    )
                                    onExportComplete("APK Built successfully: ${project.name}.apk")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_build_apk"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A4EB5)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Android, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isBuilding) "Building APK..." else "1-Click Build Android APK", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Run in Simulator
                            OutlinedButton(
                                onClick = {
                                    onDismiss()
                                    onRunInGamePreview()
                                },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, Color(0xFF00E5FF)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Run Game", color = Color(0xFF00E5FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Install on Device
                            Button(
                                onClick = {
                                    isInstallingOnDevice = true
                                    scope.launch {
                                        delay(800)
                                        isInstallingOnDevice = false
                                        installStatus = installStatus.copy(isInstalled = true)
                                        onExportComplete("Package installed into device app list!")
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676), contentColor = Color(0xFF00361A)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.InstallMobile, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isInstallingOnDevice) "Installing..." else "Install APK", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // TAB 1: CONVERT TO JAVA / KOTLIN GRADLE ANDROID APP
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("TARGET LANGUAGE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9E86FF))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Kotlin", "Java").forEach { lang ->
                                    val isSel = targetLang == lang
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable {
                                                targetLang = lang
                                                convertedProject = AndroidProjectConverter.convertToAndroidProject(project, lang)
                                                selectedFileIndex = 0
                                            },
                                        color = if (isSel) Color(0xFF5A4EB5) else Color(0xFF222534),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(lang, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // File Selector Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            convertedProject.files.take(4).forEachIndexed { idx, file ->
                                val isSel = idx == selectedFileIndex
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .clickable { selectedFileIndex = idx },
                                    color = if (isSel) Color(0xFF38325E) else Color(0xFF1E212E),
                                    border = BorderStroke(1.dp, if (isSel) Color(0xFF9E86FF) else Color.Transparent),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = file.fileName,
                                        fontSize = 10.sp,
                                        color = if (isSel) Color.White else Color(0xFF868B9F),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Generated File Code Viewer
                        val currentFile = convertedProject.files.getOrNull(selectedFileIndex) ?: convertedProject.files.first()
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            color = Color(0xFF0C0D12),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF232636))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = currentFile.filePath,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF00E5FF)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                LazyColumn(modifier = Modifier.fillMaxSize()) {
                                    items(currentFile.content.lines()) { line ->
                                        Text(
                                            text = line,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = when {
                                                line.startsWith("import ") || line.startsWith("package ") -> Color(0xFF868B9F)
                                                line.contains("class ") || line.contains("plugins ") -> Color(0xFF00E5FF)
                                                line.contains("fun ") || line.contains("void ") -> Color(0xFF9E86FF)
                                                else -> Color(0xFFD4D8E8)
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                onExportComplete("Exported complete Android Studio Gradle Project ($targetLang) to /Workspace/${project.name}_AndroidApp")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A4EB5)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export Android Studio Project ($targetLang Gradle)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
