package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UnityUser
import com.example.ui.theme.UnityAmber
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityDarkBackground
import com.example.ui.theme.UnityElectricBlue
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityRed
import com.example.ui.theme.UnityTeal
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@Composable
fun AccountScreen(
    currentUser: UnityUser?,
    onLoginClick: () -> Unit,
    onLogoutClick: () -> Unit,
    onDemoLoginClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showLogoutConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(UnityDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("account_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Screen Title
        item {
            Column {
                Text(
                    text = "Unity ID Account",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = UnityTextPrimary
                )
                Text(
                    text = "Official authentication profile and organization settings",
                    fontSize = 12.sp,
                    color = UnityTextSecondary
                )
            }
        }

        if (currentUser != null) {
            // Profile Info Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("account_profile_card"),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, UnityCyan.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF004D5A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = currentUser.displayName.take(1).uppercase(),
                                    color = UnityCyan,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column {
                                Text(
                                    text = currentUser.displayName,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = UnityTextPrimary
                                )
                                Text(
                                    text = currentUser.email,
                                    fontSize = 12.sp,
                                    color = UnityTextSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    color = Color(0xFF163828),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "AUTHENTICATED",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = UnityGreen,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Organization & Role Info
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFF1B1D23),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Active Organization", fontSize = 11.sp, color = UnityTextMuted)
                                    Text(text = currentUser.organizationName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = UnityTextPrimary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Organization ID", fontSize = 11.sp, color = UnityTextMuted)
                                    Text(text = currentUser.organizationId, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = UnityCyan)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Assigned Role", fontSize = 11.sp, color = UnityTextMuted)
                                    Text(text = currentUser.role, fontSize = 12.sp, color = UnityElectricBlue, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }

            // Hardware Keystore Session Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, UnityCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = UnityCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Secure Session Persistence",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = UnityTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Tokens are encrypted on-device via Android Keystore hardware-backed AES-GCM and stored in EncryptedSharedPreferences.",
                            fontSize = 11.sp,
                            color = UnityTextSecondary,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFF16181E),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "OAuth Access Token:",
                                    fontSize = 11.sp,
                                    color = UnityTextMuted
                                )
                                Text(
                                    text = if (currentUser.accessToken.length > 12) {
                                        "${currentUser.accessToken.take(8)}...${currentUser.accessToken.takeLast(4)}"
                                    } else "Encrypted",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = UnityGreen
                                )
                            }
                        }
                    }
                }
            }

            // Cloud Services Quota
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, UnityCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Unity Cloud Quota & Services",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Cloud Build Concurrent Slots", fontSize = 12.sp, color = UnityTextSecondary)
                            Text(text = "2 / 2 Available", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = UnityCyan)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Cloud Diagnostics Crash Reports", fontSize = 12.sp, color = UnityTextSecondary)
                            Text(text = "Unlimited (Pro Tier)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = UnityGreen)
                        }
                    }
                }
            }

            // Logout Action
            item {
                OutlinedButton(
                    onClick = { showLogoutConfirm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_logout"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = UnityRed),
                    border = BorderStroke(1.dp, UnityRed.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.ExitToApp, contentDescription = "Logout", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Sign Out of Unity ID", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // Signed Out Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("account_logged_out_card"),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, UnityCardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = null,
                            tint = UnityCyan,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Sign in to Unity ID",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Authenticate with your official Unity account to sync cloud projects, manage engine licenses, and access cloud build pipelines.",
                            fontSize = 12.sp,
                            color = UnityTextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onLoginClick,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_account_signin"),
                            colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Sign In with Unity ID / SSO", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = onDemoLoginClick,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_account_demo_login"),
                            border = BorderStroke(1.dp, UnityTeal),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Explore with Developer Demo Account", color = UnityTeal, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            containerColor = UnityCardBackground,
            title = {
                Text(text = "Sign Out?", color = UnityTextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Signing out will clear your active session credentials from the secure store. Local project files on your device will remain intact.",
                    color = UnityTextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutConfirm = false
                        onLogoutClick()
                    }
                ) {
                    Text(text = "Sign Out", color = UnityRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) {
                    Text(text = "Cancel", color = UnityTextSecondary)
                }
            }
        )
    }
}
