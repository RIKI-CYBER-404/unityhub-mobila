package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Shared palette used throughout the Unity Hub interface.
val UnityDarkBackground = Color(0xFF101116)
val UnityDarkSurface = Color(0xFF181B22)
val UnityCardBackground = Color(0xFF20242D)
val UnityCardBorder = Color(0xFF343B49)
val UnitySurfaceVariant = Color(0xFF252B36)

val UnityTextPrimary = Color(0xFFF4F6FA)
val UnityTextSecondary = Color(0xFFB7C0CE)
val UnityTextMuted = Color(0xFF818B9B)

val UnityAmber = Color(0xFFFFB547)
val UnityElectricBlue = Color(0xFF4D9CFF)
val UnityCyan = Color(0xFF35C6D8)
val UnityTeal = Color(0xFF25B7A5)
val UnityGreen = Color(0xFF35C878)
val UnityRed = Color(0xFFFF5B63)
