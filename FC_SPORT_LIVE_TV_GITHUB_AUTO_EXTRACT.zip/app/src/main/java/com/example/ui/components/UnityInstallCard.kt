package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ReleaseChannel
import com.example.data.model.UnityEditorVersion
import com.example.ui.theme.UnityAmber
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityElectricBlue
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@Composable
fun UnityInstallCard(
    editor: UnityEditorVersion,
    onAddModulesClick: () -> Unit,
    onInstallClick: () -> Unit,
    onLocateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("install_card_${editor.cleanVersion}"),
        colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, UnityCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Unity ${editor.version}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))

                        // Channel Tag
                        val channelBg = when (editor.channel) {
                            ReleaseChannel.LTS -> Color(0xFF004D5A)
                            ReleaseChannel.TECH_STREAM -> Color(0xFF1A3860)
                            ReleaseChannel.BETA -> Color(0xFF5A2A00)
                            ReleaseChannel.ARCHIVE -> Color(0xFF333333)
                        }
                        val channelColor = when (editor.channel) {
                            ReleaseChannel.LTS -> UnityCyan
                            ReleaseChannel.TECH_STREAM -> UnityElectricBlue
                            ReleaseChannel.BETA -> UnityAmber
                            ReleaseChannel.ARCHIVE -> UnityTextSecondary
                        }
                        Surface(
                            color = channelBg,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = editor.channel.displayName,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = channelColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = if (editor.isInstalled) {
                            "Installed: ${editor.installPath ?: "Standard Root"}"
                        } else {
                            "Released ${editor.releaseDate} • ~${editor.downloadSizeGb} GB download"
                        },
                        fontSize = 12.sp,
                        color = UnityTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Installed check badge
                if (editor.isInstalled) {
                    Surface(
                        color = Color(0xFF163828),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Installed",
                                tint = UnityGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Installed",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = UnityGreen
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Release Notes snippet
            if (editor.releaseNotesSummary.isNotBlank()) {
                Text(
                    text = editor.releaseNotesSummary,
                    fontSize = 12.sp,
                    color = UnityTextMuted,
                    lineHeight = 16.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Installing Progress Bar
            if (editor.isInstalling) {
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Downloading & configuring editor...",
                            fontSize = 11.sp,
                            color = UnityCyan
                        )
                        Text(
                            text = "${(editor.installProgress * 100).toInt()}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { editor.installProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = UnityCyan,
                        trackColor = Color(0xFF1E2026)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Modules info / Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (editor.isInstalled) {
                    val count = editor.installedModules.size
                    Text(
                        text = "$count build target${if (count != 1) "s" else ""} & tools active",
                        fontSize = 11.sp,
                        color = UnityTextSecondary
                    )
                } else {
                    Text(
                        text = "Official release repository",
                        fontSize = 11.sp,
                        color = UnityTextMuted
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (editor.isInstalled) {
                        // Add Modules Button
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onAddModulesClick() }
                                .testTag("btn_modules_${editor.cleanVersion}"),
                            color = Color(0xFF232A36),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Extension,
                                    contentDescription = "Modules",
                                    tint = UnityCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Add Modules",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = UnityCyan
                                )
                            }
                        }
                    } else if (!editor.isInstalling) {
                        // Locate button
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onLocateClick() },
                            color = Color(0xFF25272F),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = "Locate",
                                    tint = UnityTextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Locate",
                                    fontSize = 12.sp,
                                    color = UnityTextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Install Button
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onInstallClick() }
                                .testTag("btn_install_${editor.cleanVersion}"),
                            color = UnityCyan,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Install Unity Editor",
                                    tint = Color(0xFF00363D),
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Install",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00363D)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
