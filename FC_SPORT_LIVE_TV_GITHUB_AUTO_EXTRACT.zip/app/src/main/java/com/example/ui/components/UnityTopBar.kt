package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LicenseType
import com.example.data.model.UnityLicense
import com.example.data.model.UnityUser
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityDarkBackground
import com.example.ui.theme.UnityDarkSurface
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnityTopBar(
    currentUser: UnityUser?,
    activeLicense: UnityLicense?,
    onAccountClick: () -> Unit,
    onLicenseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TopAppBar(
        modifier = modifier
            .background(UnityDarkSurface)
            .testTag("unity_top_bar"),
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = UnityDarkSurface,
            titleContentColor = UnityTextPrimary
        ),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Sleek Unity Logo Marker
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF24262E)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "U",
                        color = UnityCyan,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SUPER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityCyan,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "HUB",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityTextPrimary
                    )
                }
            }
        },
        actions = {
            // License Pill Indicator
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onLicenseClick() }
                    .testTag("top_bar_license_pill"),
                color = Color(0xFF262832),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (activeLicense != null) UnityGreen else UnityTextMuted)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = activeLicense?.type?.displayName ?: "No License",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (activeLicense != null) UnityTextPrimary else UnityTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // User Profile Avatar / Login Icon
            IconButton(
                onClick = onAccountClick,
                modifier = Modifier.testTag("top_bar_account_button")
            ) {
                if (currentUser != null) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF004D5A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser.displayName.take(1).uppercase(),
                            color = UnityCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Sign in to Unity ID",
                        tint = UnityCyan
                    )
                }
            }
        }
    )
}
