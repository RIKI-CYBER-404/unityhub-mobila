package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BuildPlatform
import com.example.data.model.WorkspaceProject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectSettingsScreen(
    project: WorkspaceProject,
    onNavigateBack: () -> Unit,
    onPlatformChanged: (BuildPlatform) -> Unit,
    onCompanyNameChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableIntStateOf(0) } // 0: Player, 1: Tags and Layers, 2: Quality
    var companyName by remember { mutableStateOf(project.companyName) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFF0F1015),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Project Settings",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F1015)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Sub-tabs: Player | Tags and Layers | Quality
            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = Color(0xFF14151D),
                contentColor = Color(0xFF9E86FF),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
                        color = Color(0xFF9E86FF)
                    )
                }
            ) {
                listOf("Player", "Tags and Layers", "Quality").forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedSubTab == idx,
                        onClick = { selectedSubTab = idx },
                        text = {
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = if (selectedSubTab == idx) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedSubTab == idx) Color(0xFF9E86FF) else Color(0xFF9EA3B8)
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                if (selectedSubTab == 0) {
                    // Platform Section
                    Text(
                        text = "Platform",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D28)),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFF262838))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            // Standalone
                            PlatformRow(
                                initial = "S",
                                title = "Standalone",
                                subtitle = "Switch platform settings",
                                isActive = project.activePlatform == BuildPlatform.WINDOWS,
                                onClick = { onPlatformChanged(BuildPlatform.WINDOWS) }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Android
                            PlatformRow(
                                initial = "A",
                                title = "Android",
                                subtitle = if (project.activePlatform == BuildPlatform.ANDROID) "Selected platform settings" else "Switch platform settings",
                                isActive = project.activePlatform == BuildPlatform.ANDROID,
                                onClick = { onPlatformChanged(BuildPlatform.ANDROID) }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // iOS
                            PlatformRow(
                                initial = "i",
                                title = "iOS",
                                subtitle = "Switch platform settings",
                                isActive = project.activePlatform == BuildPlatform.IOS,
                                onClick = { onPlatformChanged(BuildPlatform.IOS) }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // WebGL
                            PlatformRow(
                                initial = "w",
                                title = "WebGL",
                                subtitle = "Switch platform settings",
                                isActive = project.activePlatform == BuildPlatform.WEBGL,
                                onClick = { onPlatformChanged(BuildPlatform.WEBGL) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Player Section
                    Text(
                        text = "Player",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D28)),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFF262838))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Company Name",
                                fontSize = 13.sp,
                                color = Color(0xFFA5A9BF)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = companyName,
                                onValueChange = {
                                    companyName = it
                                    onCompanyNameChanged(it)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_company_name"),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = Color(0xFF222534),
                                    unfocusedContainerColor = Color(0xFF222534),
                                    focusedBorderColor = Color(0xFF6C5CE7),
                                    unfocusedBorderColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Product Name",
                                fontSize = 13.sp,
                                color = Color(0xFFA5A9BF)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = project.name,
                                onValueChange = { },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = Color(0xFF222534),
                                    unfocusedContainerColor = Color(0xFF222534),
                                    focusedBorderColor = Color(0xFF6C5CE7),
                                    unfocusedBorderColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }
                } else if (selectedSubTab == 1) {
                    // Tags and Layers
                    Text(text = "Layers & Collision Matrix", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(10.dp))
                    listOf("Default", "TransparentFX", "Ignore Raycast", "Water", "UI", "PostProcessing").forEachIndexed { idx, layer ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "User Layer $idx", fontSize = 12.sp, color = Color(0xFF8B8FA3))
                            Text(text = layer, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium)
                        }
                    }
                } else {
                    // Quality Settings
                    Text(text = "Quality Presets", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(10.dp))
                    listOf("Very Low", "Low", "Medium", "High (Active)", "Very High", "Ultra").forEach { q ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            color = if (q.contains("Active")) Color(0xFF2A2645) else Color(0xFF1B1D28),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = q,
                                color = if (q.contains("Active")) Color(0xFF9E86FF) else Color.White,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlatformRow(
    initial: String,
    title: String,
    subtitle: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag("platform_row_$title"),
        color = if (isActive) Color(0xFF2A2844) else Color(0xFF222534),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isActive) Color(0xFF7E69FF) else Color(0xFF2E3245)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initial,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color(0xFF868B9F)
                )
            }

            if (isActive) {
                Text(
                    text = "Active",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8E7AFF)
                )
            }
        }
    }
}
