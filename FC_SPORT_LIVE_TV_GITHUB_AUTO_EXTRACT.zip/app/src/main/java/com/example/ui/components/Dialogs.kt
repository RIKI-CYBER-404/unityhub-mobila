package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.BuildPlatform
import com.example.data.model.CloudBuildJob
import com.example.data.model.EditorModule
import com.example.data.model.UnityEditorVersion
import com.example.data.model.UnityProject
import com.example.data.model.UnityTemplate
import com.example.ui.theme.UnityAmber
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityDarkBackground
import com.example.ui.theme.UnityDarkSurface
import com.example.ui.theme.UnityElectricBlue
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityRed
import com.example.ui.theme.UnitySurfaceVariant
import com.example.ui.theme.UnityTeal
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

// -------------------------------------------------------------
// 1. Create Project Dialog
// -------------------------------------------------------------

@Composable
fun CreateProjectDialog(
    templates: List<UnityTemplate>,
    installedEditors: List<UnityEditorVersion>,
    onDismiss: () -> Unit,
    onCreate: (name: String, template: UnityTemplate, editorVersion: String, targetPlatform: BuildPlatform, path: String) -> Unit
) {
    var projectName by remember { mutableStateOf("MyAwesomeGame") }
    var selectedTemplate by remember { mutableStateOf(templates.firstOrNull() ?: UnityTemplate("1", "3D", "URP", "3D", "Default", "6000.0.32f1", emptyList())) }
    var selectedEditor by remember {
        mutableStateOf(installedEditors.firstOrNull()?.version ?: "6000.0.32f1 (LTS)")
    }
    var selectedPlatform by remember { mutableStateOf(BuildPlatform.ANDROID) }
    var projectPath by remember { mutableStateOf("/storage/emulated/0/UnityProjects/MyAwesomeGame") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .testTag("dialog_create_project"),
            colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, UnityCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Create New Project",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityTextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = UnityTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Project Name
                Text(text = "PROJECT NAME", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = UnityCyan)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = projectName,
                    onValueChange = {
                        projectName = it
                        projectPath = "/storage/emulated/0/UnityProjects/${it.trim().replace(" ", "")}"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_project_name"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = UnityTextPrimary,
                        unfocusedTextColor = UnityTextPrimary,
                        focusedBorderColor = UnityCyan,
                        unfocusedBorderColor = UnityCardBorder,
                        focusedContainerColor = UnityDarkBackground,
                        unfocusedContainerColor = UnityDarkBackground
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Template Selection
                Text(text = "SELECT TEMPLATE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = UnityCyan)
                Spacer(modifier = Modifier.height(8.dp))

                templates.forEach { tpl ->
                    val isSelected = tpl.id == selectedTemplate.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedTemplate = tpl }
                            .testTag("template_${tpl.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF1B3138) else Color(0xFF1E2026)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, if (isSelected) UnityCyan else UnityCardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedTemplate = tpl },
                                colors = RadioButtonDefaults.colors(selectedColor = UnityCyan, unselectedColor = UnityTextMuted)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = tpl.title,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = UnityTextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = Color(0xFF282C35),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = tpl.renderPipeline,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = UnityCyan,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = tpl.description,
                                    fontSize = 11.sp,
                                    color = UnityTextSecondary,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Editor Version
                Text(text = "UNITY EDITOR VERSION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = UnityCyan)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val versionsToPick = if (installedEditors.isNotEmpty()) {
                        installedEditors.map { it.version }
                    } else {
                        listOf("6000.0.32f1 (LTS)", "2022.3.52f1 (LTS)")
                    }

                    versionsToPick.take(2).forEach { ver ->
                        val isSel = ver == selectedEditor
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedEditor = ver },
                            color = if (isSel) Color(0xFF004D5A) else Color(0xFF1E2026),
                            border = BorderStroke(1.dp, if (isSel) UnityCyan else UnityCardBorder),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = ver,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isSel) UnityTextPrimary else UnityTextSecondary,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Target Platform
                Text(text = "DEFAULT BUILD TARGET", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = UnityCyan)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(BuildPlatform.ANDROID, BuildPlatform.IOS, BuildPlatform.WINDOWS).forEach { plat ->
                        val isSel = plat == selectedPlatform
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedPlatform = plat },
                            color = if (isSel) Color(0xFF1A3860) else Color(0xFF1E2026),
                            border = BorderStroke(1.dp, if (isSel) UnityElectricBlue else UnityCardBorder),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = plat.displayName.substringBefore(" "),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSel) UnityTextPrimary else UnityTextSecondary,
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Create Action Button
                Button(
                    onClick = {
                        if (projectName.isNotBlank()) {
                            onCreate(projectName, selectedTemplate, selectedEditor, selectedPlatform, projectPath)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_confirm_create_project"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = UnityCyan,
                        contentColor = Color(0xFF00363D)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Create Project",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. Activate License Dialog
// -------------------------------------------------------------

@Composable
fun ActivateLicenseDialog(
    onDismiss: () -> Unit,
    onActivatePersonal: (revenueCondition: String) -> Unit,
    onActivateSerial: (serialKey: String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var serialInput by remember { mutableStateOf("SC-PRO-9842-E91A-4982") }
    var selectedRevenue by remember { mutableStateOf("Gross revenue < \$100,000 USD/year") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("dialog_activate_license"),
            colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, UnityCardBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Activate Unity License",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityTextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = UnityTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tab Switcher
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFF1B1D23),
                    contentColor = UnityCyan,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = UnityCyan
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Unity Personal", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Pro / Enterprise Serial", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (selectedTab == 0) {
                    // Personal Free License Flow
                    Text(
                        text = "ELIGIBILITY DECLARATION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityCyan
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Unity Personal is available for free to individuals and small organizations that do not have gross revenues or funds raised exceeding \$100,000 USD in the previous 12 months.",
                        fontSize = 12.sp,
                        color = UnityTextSecondary,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    listOf(
                        "I don't use Unity in a professional capacity",
                        "Gross revenue < \$100,000 USD/year",
                        "Student / Educational use"
                    ).forEach { condition ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRevenue = condition }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = selectedRevenue == condition,
                                onClick = { selectedRevenue = condition },
                                colors = RadioButtonDefaults.colors(selectedColor = UnityCyan, unselectedColor = UnityTextMuted)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = condition, fontSize = 13.sp, color = UnityTextPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { onActivatePersonal(selectedRevenue) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("btn_confirm_activate_personal"),
                        colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "Activate Free Personal License", fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Pro / Enterprise Serial Key
                    Text(
                        text = "ENTER SERIAL NUMBER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityCyan
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Format: U3-XXXX-XXXX-XXXX-XXXX or SC-XXXX-XXXX-XXXX",
                        fontSize = 11.sp,
                        color = UnityTextMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .clickable {
                                    serialInput = "U3-PERS-8921-X992-K821-V491"
                                },
                            color = Color(0xFF1F2230),
                            border = BorderStroke(1.dp, UnityCyan.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "Use Personal Key",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = UnityCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .clickable {
                                    serialInput = "SC-PRO-6000-X771-N902-L318"
                                },
                            color = Color(0xFF1F2230),
                            border = BorderStroke(1.dp, UnityAmber.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "Use Pro Key",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = UnityAmber,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = serialInput,
                        onValueChange = { serialInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_serial_key"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = UnityTextPrimary,
                            unfocusedTextColor = UnityTextPrimary,
                            focusedBorderColor = UnityCyan,
                            unfocusedBorderColor = UnityCardBorder,
                            focusedContainerColor = UnityDarkBackground,
                            unfocusedContainerColor = UnityDarkBackground
                        )
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { onActivateSerial(serialInput) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("btn_confirm_activate_serial"),
                        colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "Verify & Bind License", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 3. Add Modules Dialog
// -------------------------------------------------------------

@Composable
fun AddModulesDialog(
    editor: UnityEditorVersion,
    onDismiss: () -> Unit,
    onToggleModule: (moduleId: String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .testTag("dialog_add_modules"),
            colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, UnityCardBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Add Modules",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                        Text(
                            text = "Unity ${editor.cleanVersion}",
                            fontSize = 12.sp,
                            color = UnityCyan
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = UnityTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(editor.availableModules) { mod ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onToggleModule(mod.id) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (mod.isInstalled) Color(0xFF162D24) else Color(0xFF1E2026)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(
                                1.dp,
                                if (mod.isInstalled) UnityGreen.copy(alpha = 0.5f) else UnityCardBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = mod.isInstalled,
                                    onCheckedChange = { onToggleModule(mod.id) },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = UnityGreen,
                                        checkmarkColor = Color(0xFF003730),
                                        uncheckedColor = UnityTextMuted
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = mod.name,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = UnityTextPrimary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${mod.sizeMb} MB",
                                            fontSize = 11.sp,
                                            color = UnityTextSecondary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = mod.description,
                                        fontSize = 11.sp,
                                        color = UnityTextMuted,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Save & Apply Changes", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. Cloud Build Dialog
// -------------------------------------------------------------

@Composable
fun CloudBuildDialog(
    buildJob: CloudBuildJob,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .testTag("dialog_cloud_build"),
            colors = CardDefaults.cardColors(containerColor = UnityDarkBackground),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, UnityCyan.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Unity Cloud Build",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                        Text(
                            text = "${buildJob.projectName} • ${buildJob.platform.displayName}",
                            fontSize = 12.sp,
                            color = UnityCyan
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = UnityTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Progress Bar
                LinearProgressIndicator(
                    progress = { buildJob.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (buildJob.status == "SUCCESS") UnityGreen else UnityCyan,
                    trackColor = Color(0xFF232630)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Status: ${buildJob.status}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (buildJob.status == "SUCCESS") UnityGreen else UnityAmber
                    )
                    Text(
                        text = "${(buildJob.progress * 100).toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityCyan
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Real-time Console Terminal
                Text(
                    text = "BUILD TERMINAL LOG",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = UnityTextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    color = Color(0xFF0C0D10),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFF22242D))
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .padding(10.dp)
                            .testTag("build_log_console")
                    ) {
                        items(buildJob.logOutput) { logLine ->
                            Text(
                                text = logLine,
                                color = when {
                                    logLine.contains("[Success]") -> UnityGreen
                                    logLine.contains("[Error]") -> UnityRed
                                    logLine.contains("[IL2CPP]") -> UnityElectricBlue
                                    else -> Color(0xFFC0C4D0)
                                },
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (buildJob.status == "SUCCESS") {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = UnityGreen, contentColor = Color(0xFF003319)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Download Artifact (APK)", fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, UnityCardBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "Run in Background", color = UnityTextSecondary)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 5. Unity Login / SSO Dialog
// -------------------------------------------------------------

@Composable
fun UnityLoginDialog(
    onDismiss: () -> Unit,
    onOAuthLogin: (code: String) -> Unit,
    onTokenLogin: (email: String, token: String, displayName: String) -> Unit,
    onDemoLogin: () -> Unit,
    onCreateAccount: (name: String, email: String, username: String, orgName: String) -> Unit = { _, _, _, _ -> }
) {
    var selectedAuthTab by remember { mutableIntStateOf(0) }
    var newFullName by remember { mutableStateOf("Picchi Developer") }
    var newUsername by remember { mutableStateOf("picchi_dev") }
    var newEmail by remember { mutableStateOf("picchi@unitygame.io") }
    var newOrg by remember { mutableStateOf("Super Unity Games") }

    var emailInput by remember { mutableStateOf("dev@unitystudio.io") }
    var tokenInput by remember { mutableStateOf("upat_sec_8921a4819bd9420fae") }
    var displayNameInput by remember { mutableStateOf("Marcus Wright") }
    var isSimulatingOAuth by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .testTag("dialog_unity_login"),
            colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, UnityCyan.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = UnityCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Unity ID Authentication",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = UnityTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs: Create Account vs Official SSO vs Personal Access Token vs Demo
                ScrollableTabRow(
                    selectedTabIndex = selectedAuthTab,
                    containerColor = Color(0xFF1B1D23),
                    contentColor = UnityCyan,
                    edgePadding = 0.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedAuthTab]),
                            color = UnityCyan
                        )
                    }
                ) {
                    Tab(
                        selected = selectedAuthTab == 0,
                        onClick = { selectedAuthTab = 0 },
                        text = { Text("Create Account", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedAuthTab == 1,
                        onClick = { selectedAuthTab = 1 },
                        text = { Text("Unity SSO", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedAuthTab == 2,
                        onClick = { selectedAuthTab = 2 },
                        text = { Text("API Token", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedAuthTab == 3,
                        onClick = { selectedAuthTab = 3 },
                        text = { Text("Demo User", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                when (selectedAuthTab) {
                    0 -> {
                        // Create Account Tab
                        Text(
                            text = "CREATE OFFICIAL UNITY ID ACCOUNT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Register a new Unity ID to activate your free Personal License, manage cloud storage, and build mobile games.",
                            fontSize = 12.sp,
                            color = UnityTextSecondary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = newFullName,
                            onValueChange = { newFullName = it },
                            label = { Text("Full Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("input_create_fullname"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = UnityTextPrimary,
                                unfocusedTextColor = UnityTextPrimary,
                                focusedBorderColor = UnityCyan,
                                unfocusedBorderColor = UnityCardBorder,
                                focusedContainerColor = UnityDarkBackground,
                                unfocusedContainerColor = UnityDarkBackground
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newEmail,
                            onValueChange = { newEmail = it },
                            label = { Text("Email Address") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("input_create_email"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = UnityTextPrimary,
                                unfocusedTextColor = UnityTextPrimary,
                                focusedBorderColor = UnityCyan,
                                unfocusedBorderColor = UnityCardBorder,
                                focusedContainerColor = UnityDarkBackground,
                                unfocusedContainerColor = UnityDarkBackground
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newUsername,
                                onValueChange = { newUsername = it },
                                label = { Text("Username") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("input_create_username"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = UnityTextPrimary,
                                    unfocusedTextColor = UnityTextPrimary,
                                    focusedBorderColor = UnityCyan,
                                    unfocusedBorderColor = UnityCardBorder,
                                    focusedContainerColor = UnityDarkBackground,
                                    unfocusedContainerColor = UnityDarkBackground
                                )
                            )
                            OutlinedTextField(
                                value = newOrg,
                                onValueChange = { newOrg = it },
                                label = { Text("Organization") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("input_create_org"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = UnityTextPrimary,
                                    unfocusedTextColor = UnityTextPrimary,
                                    focusedBorderColor = UnityCyan,
                                    unfocusedBorderColor = UnityCardBorder,
                                    focusedContainerColor = UnityDarkBackground,
                                    unfocusedContainerColor = UnityDarkBackground
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFF132A1F),
                            border = BorderStroke(1.dp, Color(0xFF00E676)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Check, null, tint = Color(0xFF00E676), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Includes 100% Free Unity Personal License",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF55EFC4)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                onCreateAccount(newFullName, newEmail, newUsername, newOrg)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_create_account_submit"),
                            colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Create Unity Account & Activate", fontWeight = FontWeight.Bold)
                        }
                    }
                    1 -> {
                        // Unity Web SSO
                        Text(
                            text = "OFFICIAL UNITY WEB SSO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Authenticate via Unity's official OAuth 2.0 portal (https://id.unity.com). Your session tokens will be securely saved in hardware-backed EncryptedSharedPreferences.",
                            fontSize = 12.sp,
                            color = UnityTextSecondary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFF181A20),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF2E313D))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "OAuth Client Endpoint:",
                                    fontSize = 10.sp,
                                    color = UnityTextMuted
                                )
                                Text(
                                    text = "https://id.unity.com/oauth/authorize",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = UnityCyan
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = {
                                isSimulatingOAuth = true
                                onOAuthLogin("unity_code_${System.currentTimeMillis()}")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_unity_sso_submit"),
                            colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Authorize with Unity ID", fontWeight = FontWeight.Bold)
                        }
                    }
                    2 -> {
                        // Personal Access Token
                        Text(
                            text = "ENTER PERSONAL ACCESS TOKEN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityCyan
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Unity ID Email") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = UnityTextPrimary,
                                unfocusedTextColor = UnityTextPrimary,
                                focusedBorderColor = UnityCyan,
                                unfocusedBorderColor = UnityCardBorder,
                                focusedContainerColor = UnityDarkBackground,
                                unfocusedContainerColor = UnityDarkBackground
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = tokenInput,
                            onValueChange = { tokenInput = it },
                            label = { Text("Unity API Token (UPAT)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = UnityTextPrimary,
                                unfocusedTextColor = UnityTextPrimary,
                                focusedBorderColor = UnityCyan,
                                unfocusedBorderColor = UnityCardBorder,
                                focusedContainerColor = UnityDarkBackground,
                                unfocusedContainerColor = UnityDarkBackground
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { onTokenLogin(emailInput, tokenInput, displayNameInput) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Connect with Token", fontWeight = FontWeight.Bold)
                        }
                    }
                    3 -> {
                        // Quick Demo
                        Text(
                            text = "DEVELOPER DEMO ACCOUNT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityCyan
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Instantly explore Super Unity Hub with a pre-configured developer profile (Alex Rivera, Lead Technical Director), active Unity Pro license, and multi-platform projects.",
                            fontSize = 12.sp,
                            color = UnityTextSecondary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = onDemoLogin,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_demo_login"),
                            colors = ButtonDefaults.buttonColors(containerColor = UnityTeal, contentColor = Color(0xFF003730)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Launch Demo Workspace", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 6. Project Details & Settings Sheet
// -------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProjectDetailsSheet(
    project: UnityProject,
    onDismiss: () -> Unit,
    onLaunch: () -> Unit,
    onCloudBuild: () -> Unit,
    onSwitchPlatform: (BuildPlatform) -> Unit,
    onDelete: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = UnityCardBackground,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = project.name,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityTextPrimary
                    )
                    Text(
                        text = project.template,
                        fontSize = 13.sp,
                        color = UnityCyan
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = UnityTextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Switch Build Target Platform
            Text(text = "TARGET BUILD PLATFORM", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = UnityCyan)
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                BuildPlatform.values().forEach { plat ->
                    val isSelected = plat == project.targetPlatform
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onSwitchPlatform(plat) },
                        color = if (isSelected) Color(0xFF004D5A) else Color(0xFF1E2026),
                        border = BorderStroke(1.dp, if (isSelected) UnityCyan else UnityCardBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = plat.displayName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isSelected) UnityTextPrimary else UnityTextSecondary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Project Path & VCS
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF191B21),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "Storage Path", fontSize = 10.sp, color = UnityTextMuted)
                    Text(text = project.path, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = UnityTextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Git Repository", fontSize = 10.sp, color = UnityTextMuted)
                    Text(text = "Branch: ${project.gitBranch} (${project.gitCommitHash})", fontSize = 11.sp, color = UnityTextPrimary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Packages Installed
            Text(
                text = "INSTALLED PACKAGES (${project.packages.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = UnityCyan
            )
            Spacer(modifier = Modifier.height(6.dp))

            project.packages.forEach { pkg ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = pkg.name, fontSize = 12.sp, color = UnityTextPrimary)
                    Text(text = "v${pkg.version}", fontSize = 11.sp, color = UnityTextMuted)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onCloudBuild,
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, UnityCyan),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Cloud Build", color = UnityCyan, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = onLaunch,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Open Editor", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            TextButton(
                onClick = onDelete,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = UnityRed, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Remove Project from Super Hub", color = UnityRed)
            }
        }
    }
}

// -------------------------------------------------------------
// 7. Locate Editor Dialog
// -------------------------------------------------------------

@Composable
fun LocateEditorDialog(
    onDismiss: () -> Unit,
    onLocate: (version: String, path: String) -> Unit
) {
    var versionInput by remember { mutableStateOf("6000.0.32f1") }
    var pathInput by remember { mutableStateOf("/opt/unity/editors/6000.0.32f1") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = UnityCardBackground,
        title = {
            Text(text = "Locate Existing Editor", color = UnityTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(
                    text = "Link an existing Unity Editor binary installed on local storage or external drive.",
                    color = UnityTextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = versionInput,
                    onValueChange = { versionInput = it },
                    label = { Text("Version String (e.g. 6000.0.32f1)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = UnityTextPrimary,
                        unfocusedTextColor = UnityTextPrimary,
                        focusedBorderColor = UnityCyan,
                        unfocusedBorderColor = UnityCardBorder,
                        focusedContainerColor = UnityDarkBackground,
                        unfocusedContainerColor = UnityDarkBackground
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = pathInput,
                    onValueChange = { pathInput = it },
                    label = { Text("Executable / Installation Path") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = UnityTextPrimary,
                        unfocusedTextColor = UnityTextPrimary,
                        focusedBorderColor = UnityCyan,
                        unfocusedBorderColor = UnityCardBorder,
                        focusedContainerColor = UnityDarkBackground,
                        unfocusedContainerColor = UnityDarkBackground
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onLocate(versionInput, pathInput) },
                colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D))
            ) {
                Text(text = "Locate & Link")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Cancel", color = UnityTextSecondary)
            }
        }
    )
}
