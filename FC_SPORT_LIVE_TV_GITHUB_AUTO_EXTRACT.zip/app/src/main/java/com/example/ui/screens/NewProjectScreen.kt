package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WorkspaceProject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewProjectScreen(
    onNavigateBack: () -> Unit,
    onCreateProject: (name: String, pkgName: String, location: String, templateTitle: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var projectName by remember { mutableStateOf("") }
    var packageName by remember { mutableStateOf("com.example.unity") }
    val defaultLocation = "/data/user/0/com.m4coding.superunity/files/Workspace/Workspace"

    val templates = listOf(
        "Canyon Flight Starter" to ("Arcade flight starter with mobile-friendly canyon traversal, energy gates, and a ready-to-tune retry loop." to "mobile • arcade • flight"),
        "Rising XI 3D Football" to ("Fast-paced mobile football simulator with dynamic goalkeeper AI and stadium crowds." to "mobile • 3D • sports"),
        "2D Pixel Platformer" to ("Pixel-art platformer with character controller, collectibles, and parallax backgrounds." to "mobile • 2D • platformer"),
        "Universal 3D (URP)" to ("Standard Universal Render Pipeline setup for high-fidelity cross-platform 3D." to "mobile • 3D • URP")
    )

    var selectedTemplateIndex by remember { mutableStateOf(0) }
    var templateDropdownExpanded by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFF0F1015),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Game Create",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F1015)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_new_project_form"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D28)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF272939))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "New project",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Project name
                    Text(
                        text = "Project name",
                        fontSize = 13.sp,
                        color = Color(0xFFA5A9BF)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        placeholder = { Text("e.g. MyMobileGame", color = Color(0xFF55596D), fontSize = 13.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_project_name_field"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF222534),
                            unfocusedContainerColor = Color(0xFF222534),
                            focusedBorderColor = Color(0xFF6C5CE7),
                            unfocusedBorderColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // App package name
                    Text(
                        text = "App package name",
                        fontSize = 13.sp,
                        color = Color(0xFFA5A9BF)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = packageName,
                        onValueChange = { packageName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_package_name_field"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF222534),
                            unfocusedContainerColor = Color(0xFF222534),
                            focusedBorderColor = Color(0xFF6C5CE7),
                            unfocusedBorderColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Location
                    Text(
                        text = "Location",
                        fontSize = 13.sp,
                        color = Color(0xFFA5A9BF)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = defaultLocation,
                        fontSize = 11.sp,
                        color = Color(0xFF6C7186),
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Template Dropdown
                    Text(
                        text = "Template",
                        fontSize = 13.sp,
                        color = Color(0xFFA5A9BF)
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Box {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { templateDropdownExpanded = true }
                                .testTag("template_dropdown_button"),
                            color = Color(0xFF222534),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = templates[selectedTemplateIndex].first,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Dropdown",
                                    tint = Color.White
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = templateDropdownExpanded,
                            onDismissRequest = { templateDropdownExpanded = false },
                            modifier = Modifier
                                .background(Color(0xFF252838))
                                .fillMaxWidth(0.85f)
                        ) {
                            templates.forEachIndexed { index, (title, _) ->
                                DropdownMenuItem(
                                    text = { Text(text = title, color = Color.White) },
                                    onClick = {
                                        selectedTemplateIndex = index
                                        templateDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Curated Unity starters for quick project setup without extra template baggage.",
                        fontSize = 12.sp,
                        color = Color(0xFF868B9F),
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = templates[selectedTemplateIndex].second.first,
                        fontSize = 12.sp,
                        color = Color(0xFFD3D7E8),
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = templates[selectedTemplateIndex].second.second,
                        fontSize = 11.sp,
                        color = Color(0xFF6B7085)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Git repository will be created automatically",
                        fontSize = 11.sp,
                        color = Color(0xFF7E849E)
                    )

                    Spacer(modifier = Modifier.height(22.dp))

                    Button(
                        onClick = {
                            val finalName = projectName.trim().ifBlank { "NewUnityGame" }
                            onCreateProject(
                                finalName,
                                packageName,
                                defaultLocation,
                                templates[selectedTemplateIndex].first
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_submit_create_project"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF5A4EB5),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Create & Open Workspace",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
