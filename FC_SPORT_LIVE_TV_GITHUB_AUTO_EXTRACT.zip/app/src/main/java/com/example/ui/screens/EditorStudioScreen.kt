package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.VideogameAsset
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.EditorViewMode
import com.example.data.model.FileNode
import com.example.data.model.OpenTab
import com.example.data.model.SceneGameObject
import com.example.data.model.WorkspaceProject
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorStudioScreen(
    project: WorkspaceProject,
    openTabs: List<OpenTab>,
    selectedTabId: String?,
    activeFileContent: String,
    onTabSelected: (String) -> Unit,
    onTabClosed: (String) -> Unit,
    onFileContentChanged: (String) -> Unit,
    onSaveFile: () -> Unit,
    onOpenFile: (path: String, name: String, isScene: Boolean) -> Unit,
    onCreateNewFile: (parentPath: String, fileName: String, isDir: Boolean) -> Unit,
    onNavigateProjectSettings: () -> Unit,
    onNavigateBackToHome: () -> Unit,
    onTriggerBuild: () -> Unit,
    isDarkTheme: Boolean = true,
    onToggleTheme: () -> Unit = {},
    onOpenBuildAndInstall: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var viewMode by remember { mutableStateOf(EditorViewMode.CONTENT) }
    var fileMenuExpanded by remember { mutableStateOf(false) }
    var overflowMenuExpanded by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var showOpenCodeAIDialog by remember { mutableStateOf(false) }
    var showFindDialog by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = if (isDarkTheme) Color(0xFF13151E) else Color(0xFFF3F4F8),
                modifier = Modifier.width(310.dp)
            ) {
                FileBrowserPanel(
                    root = project.rootFolder,
                    onFileClick = { path, name, isScene ->
                        onOpenFile(path, name, isScene)
                        if (isScene) viewMode = EditorViewMode.CONTENT
                        else viewMode = EditorViewMode.CODE
                        scope.launch { drawerState.close() }
                    },
                    onAddFileClick = { showNewFileDialog = true },
                    onCloseDrawer = { scope.launch { drawerState.close() } }
                )
            }
        }
    ) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            containerColor = if (isDarkTheme) Color(0xFF0F1015) else Color(0xFFF0F2F7),
            topBar = {
                TopAppBar(
                    modifier = Modifier.background(if (isDarkTheme) Color(0xFF0F1015) else Color(0xFFF0F2F7)),
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = if (isDarkTheme) Color(0xFF0F1015) else Color(0xFFF0F2F7)),
                    title = { /* Empty to fit action icons */ },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("btn_editor_drawer")
                        ) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu", tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24))
                        }
                    },
                    actions = {
                        // Play / Run Button
                        IconButton(
                            onClick = {
                                viewMode = EditorViewMode.PREVIEW
                            },
                            modifier = Modifier.testTag("btn_editor_play")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Run Game",
                                tint = Color(0xFF6C5CE7)
                            )
                        }

                        // Build & Install APK Button
                        IconButton(
                            onClick = onOpenBuildAndInstall,
                            modifier = Modifier.testTag("btn_top_build_apk")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Android,
                                contentDescription = "Build & Install APK",
                                tint = Color(0xFF00E676)
                            )
                        }

                        // Folder / File Menu Dropdown
                        Box {
                            IconButton(
                                onClick = { fileMenuExpanded = true },
                                modifier = Modifier.testTag("btn_editor_file_menu")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = "File Menu",
                                    tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)
                                )
                            }

                            DropdownMenu(
                                expanded = fileMenuExpanded,
                                onDismissRequest = { fileMenuExpanded = false },
                                modifier = Modifier
                                    .background(if (isDarkTheme) Color(0xFF222534) else Color(0xFFFFFFFF))
                                    .width(180.dp)
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Add, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("New", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        fileMenuExpanded = false
                                        showNewFileDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.FolderOpen, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("Open", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        fileMenuExpanded = false
                                        scope.launch { drawerState.open() }
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Save, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("Save", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        fileMenuExpanded = false
                                        onSaveFile()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Save, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("Save As", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        fileMenuExpanded = false
                                        onSaveFile()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Refresh, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("Reload", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        fileMenuExpanded = false
                                    }
                                )
                            }
                        }

                        // Edit Button (switches to code)
                        IconButton(
                            onClick = { viewMode = EditorViewMode.CODE },
                            modifier = Modifier.testTag("btn_editor_edit_toggle")
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Code", tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24))
                        }

                        // Theme Mode Toggle (Dark / Light)
                        IconButton(
                            onClick = onToggleTheme,
                            modifier = Modifier.testTag("btn_toggle_dark_light")
                        ) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Dark/Light Mode",
                                tint = Color(0xFFFFB300)
                            )
                        }

                        // Undo
                        IconButton(onClick = { /* Undo action */ }) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo", tint = Color(0xFFA0A5BF))
                        }

                        // Redo
                        IconButton(onClick = { /* Redo action */ }) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo", tint = Color(0xFFA0A5BF))
                        }

                        // Overflow 3-dots Menu
                        Box {
                            IconButton(
                                onClick = { overflowMenuExpanded = true },
                                modifier = Modifier.testTag("btn_editor_overflow")
                            ) {
                                Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More", tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24))
                            }

                            DropdownMenu(
                                expanded = overflowMenuExpanded,
                                onDismissRequest = { overflowMenuExpanded = false },
                                modifier = Modifier
                                    .background(if (isDarkTheme) Color(0xFF222534) else Color(0xFFFFFFFF))
                                    .width(230.dp)
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Android, null, tint = Color(0xFF00E676)) },
                                    text = { Text("Build & Install APK", color = Color(0xFF00E676), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        overflowMenuExpanded = false
                                        onOpenBuildAndInstall()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Code, null, tint = Color(0xFF9E86FF)) },
                                    text = { Text("Convert to Java / Kotlin", color = Color(0xFF9E86FF), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        overflowMenuExpanded = false
                                        onOpenBuildAndInstall()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Search, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("Find", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    onClick = {
                                        overflowMenuExpanded = false
                                        showFindDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Code, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("OpenCode AI", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    onClick = {
                                        overflowMenuExpanded = false
                                        showOpenCodeAIDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Folder, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("Project Settings", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    onClick = {
                                        overflowMenuExpanded = false
                                        onNavigateProjectSettings()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Menu, null, tint = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    text = { Text("Back to Workspaces", color = if (isDarkTheme) Color.White else Color(0xFF1A1C24)) },
                                    onClick = {
                                        overflowMenuExpanded = false
                                        onNavigateBackToHome()
                                    }
                                )
                            }
                        }
                    }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Tab Header Bar (Screenshots 10, 11, 12)
                if (openTabs.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF14151E))
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        openTabs.forEach { tab ->
                            val isSelected = tab.id == selectedTabId
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                    .clickable { onTabSelected(tab.id) }
                                    .testTag("tab_${tab.title}"),
                                color = if (isSelected) Color(0xFF222534) else Color(0xFF181A24),
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFF5A4EB5) else Color.Transparent)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${tab.title}${if (tab.isDirty) "*" else ""}",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else Color(0xFF868B9F)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close",
                                        tint = Color(0xFF868B9F),
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clickable { onTabClosed(tab.id) }
                                    )
                                }
                            }
                        }
                    }
                }

                // If No Open Files (Screenshots 1 & 3)
                if (openTabs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 60.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.FindInPage,
                                contentDescription = null,
                                tint = Color(0xFF535872),
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "No open files",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { scope.launch { drawerState.open() } },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF5A4EB5),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Open File Browser")
                            }
                        }
                    }
                } else {
                    // Segmented Mode Switcher: Code | Content | Preview (Screenshots 10, 11, 12)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SegmentedButton(
                            title = "Code",
                            isSelected = viewMode == EditorViewMode.CODE,
                            onClick = { viewMode = EditorViewMode.CODE },
                            modifier = Modifier.weight(1f)
                        )
                        SegmentedButton(
                            title = "Content",
                            isSelected = viewMode == EditorViewMode.CONTENT,
                            onClick = { viewMode = EditorViewMode.CONTENT },
                            modifier = Modifier.weight(1f)
                        )
                        SegmentedButton(
                            title = "Preview",
                            isSelected = viewMode == EditorViewMode.PREVIEW,
                            onClick = { viewMode = EditorViewMode.PREVIEW },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Content View by Mode
                    when (viewMode) {
                        EditorViewMode.CODE -> {
                            CodeEditorPane(
                                content = activeFileContent,
                                onContentChange = onFileContentChanged,
                                onSave = onSaveFile
                            )
                        }
                        EditorViewMode.CONTENT -> {
                            ScenesInspectorPane(
                                gameObjects = project.sceneObjects
                            )
                        }
                        EditorViewMode.PREVIEW -> {
                            InteractiveGameViewport(
                                projectName = project.name,
                                onOpenBuildAndInstall = onOpenBuildAndInstall
                            )
                        }
                    }
                }
            }
        }
    }

    // New File / Folder Dialog
    if (showNewFileDialog) {
        var newFileName by remember { mutableStateOf("NewScript.cs") }
        var isDir by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showNewFileDialog = false },
            containerColor = Color(0xFF1B1D28),
            title = { Text("Create File / Folder", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Enter filename (e.g. PlayerController.cs or Level2.unity):", fontSize = 12.sp, color = Color(0xFFA5A9BF))
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF6C5CE7),
                            focusedContainerColor = Color(0xFF222534),
                            unfocusedContainerColor = Color(0xFF222534)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNewFileDialog = false
                        if (newFileName.isNotBlank()) {
                            onCreateNewFile("Assets/Scripts", newFileName.trim(), isDir)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A4EB5))
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFileDialog = false }) {
                    Text("Cancel", color = Color(0xFF868B9F))
                }
            }
        )
    }

    // AI OpenCode Dialog
    if (showOpenCodeAIDialog) {
        var promptText by remember { mutableStateOf("Generate mobile touch joystick controls for RocketController.cs") }
        var isGenerating by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showOpenCodeAIDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D28)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("OpenCode AI Assistant", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Prompt AI to write Unity C# scripts, shaders, or math logic.", fontSize = 12.sp, color = Color(0xFFA5A9BF))
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = promptText,
                        onValueChange = { promptText = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF6C5CE7),
                            focusedContainerColor = Color(0xFF222534),
                            unfocusedContainerColor = Color(0xFF222534)
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            isGenerating = true
                            scope.launch {
                                delay(800)
                                val code = "// Generated by OpenCode AI\n// Touch input and mobile handling ready!\n" + activeFileContent
                                onFileContentChanged(code)
                                isGenerating = false
                                showOpenCodeAIDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A4EB5))
                    ) {
                        Text(if (isGenerating) "Generating..." else "Apply to Active Script")
                    }
                }
            }
        }
    }

    // Find Dialog
    if (showFindDialog) {
        var searchQuery by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFindDialog = false },
            containerColor = Color(0xFF1B1D28),
            title = { Text("Find in File", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search text...", color = Color(0xFF666B80)) },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = { showFindDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A4EB5))) {
                    Text("Find Next")
                }
            }
        )
    }
}

// -----------------------------------------------------------------
// Sub-Components
// -----------------------------------------------------------------

@Composable
private fun SegmentedButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag("tab_mode_$title"),
        color = if (isSelected) Color(0xFF3B356D) else Color(0xFF1B1D28),
        border = BorderStroke(1.dp, if (isSelected) Color(0xFF6C5CE7) else Color(0xFF252838)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else Color(0xFF9E86FF),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 8.dp)
        )
    }
}

// 1. File Browser Panel (Screenshot 7)
@Composable
private fun FileBrowserPanel(
    root: FileNode,
    onFileClick: (path: String, name: String, isScene: Boolean) -> Unit,
    onAddFileClick: () -> Unit,
    onCloseDrawer: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF13151E))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "File Browser",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Row {
                IconButton(onClick = onAddFileClick) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add", tint = Color.White)
                }
                IconButton(onClick = onCloseDrawer) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(root.children) { node ->
                FileTreeNodeView(node = node, onFileClick = onFileClick)
            }
        }
    }
}

@Composable
private fun FileTreeNodeView(
    node: FileNode,
    onFileClick: (path: String, name: String, isScene: Boolean) -> Unit,
    depth: Int = 0
) {
    var expanded by remember { mutableStateOf(node.isExpanded) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (node.isDirectory) {
                        expanded = !expanded
                    } else {
                        onFileClick(node.path, node.name, node.extension == "unity")
                    }
                }
                .padding(vertical = 4.dp, horizontal = (depth * 12).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (node.isDirectory) {
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = Color(0xFFA5A9BF),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Folder,
                    contentDescription = null,
                    tint = Color(0xFF42A5F5),
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Spacer(modifier = Modifier.width(20.dp))
                if (node.extension == "cs") {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF1B4D3E)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("C#", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E676))
                    }
                } else if (node.extension == "unity") {
                    Icon(
                        imageVector = Icons.Outlined.VideogameAsset,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(18.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Outlined.Description,
                        contentDescription = null,
                        tint = Color(0xFFA5A9BF),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = node.name,
                fontSize = 13.sp,
                fontWeight = if (node.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
                color = if (node.extension == "cs") Color(0xFFE2E4EB) else Color.White
            )
        }

        if (node.isDirectory && expanded) {
            node.children.forEach { child ->
                FileTreeNodeView(node = child, onFileClick = onFileClick, depth = depth + 1)
            }
        }
    }
}

// 2. Code Editor Pane
@Composable
private fun CodeEditorPane(
    content: String,
    onContentChange: (String) -> Unit,
    onSave: () -> Unit
) {
    val lines = content.lines()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0D12))
    ) {
        // Line numbered editor
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(8.dp)
        ) {
            // Line numbers column
            Column(
                modifier = Modifier
                    .width(36.dp)
                    .padding(end = 8.dp),
                horizontalAlignment = Alignment.End
            ) {
                for (i in 1..maxOf(lines.size, 1)) {
                    Text(
                        text = "$i",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF4A4E65),
                        lineHeight = 18.sp
                    )
                }
            }

            // Editable Code Area
            BasicTextField(
                value = content,
                onValueChange = onContentChange,
                textStyle = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = Color(0xFFE4E6F0),
                    lineHeight = 18.sp
                ),
                cursorBrush = SolidColor(Color(0xFF6C5CE7)),
                modifier = Modifier
                    .weight(1f)
                    .testTag("code_editor_input")
            )
        }

        // Quick Symbol Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF161824))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(";", "{", "}", "(", ")", "=", ".", "public", "void", "float", "Vector3", "Debug.Log").forEach { symbol ->
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable {
                            onContentChange("$content$symbol")
                        },
                    color = Color(0xFF222536),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = symbol,
                        color = Color(0xFFB0B4C8),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

// 3. Scenes Inspector Pane (Screenshots 10 & 11)
@Composable
private fun ScenesInspectorPane(
    gameObjects: List<SceneGameObject>
) {
    var selectedObj by remember { mutableStateOf(gameObjects.firstOrNull()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1015))
            .padding(14.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Hierarchy",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Hierarchy List
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D28)),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, Color(0xFF262838))
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                gameObjects.forEach { obj ->
                    val isSel = obj.name == selectedObj?.name
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { selectedObj = obj }
                            .testTag("hierarchy_item_${obj.name}"),
                        color = if (isSel) Color(0xFF2A2645) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = obj.name,
                                fontSize = 13.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) Color.White else Color(0xFFD0D3E2)
                            )

                            Surface(
                                color = Color(0xFF5A4EB5),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.clickable { selectedObj = obj }
                            ) {
                                Text(
                                    text = "View",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Inspector Controls
        Text(
            text = "Inspector",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Action links: Up, Down, Set Parent, Duplicate
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            listOf("Up", "Down", "Set Parent", "Duplicate").forEach { action ->
                Text(
                    text = action,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF9E86FF),
                    modifier = Modifier.clickable { }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selected GameObject Details Card
        selectedObj?.let { obj ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D28)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFF262838))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Transform",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF9E86FF)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    TransformRow(label = "Position", x = "0.00", y = "1.50", z = "0.00")
                    TransformRow(label = "Rotation", x = "0.00", y = "0.00", z = "0.00")
                    TransformRow(label = "Scale", x = "1.00", y = "1.00", z = "1.00")

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Components",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF9E86FF)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    obj.components.forEach { comp ->
                        Text(
                            text = "• $comp",
                            fontSize = 12.sp,
                            color = Color(0xFFD0D3E2),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TransformRow(label: String, x: String, y: String, z: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = Color(0xFF868B9F), modifier = Modifier.width(60.dp))
        Text(text = "X: $x", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
        Text(text = "Y: $y", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
        Text(text = "Z: $z", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
    }
}

// 4. Interactive Game Viewport (Screenshot 12)
// 4. Interactive 3D & 2D Game Viewport (Screenshots 3, 12 + 3D Mobile Engine)
private enum class GameEngineMode(val title: String, val icon: String) {
    FOOTBALL_3D("⚽ 3D Football (RisingXI)", "⚽"),
    CANYON_3D("🚀 3D Canyon Flight", "🚀"),
    ARCADE_2D("🕹️ Pixel Flight (Arcade)", "🕹️")
}

@Composable
private fun InteractiveGameViewport(
    projectName: String,
    onOpenBuildAndInstall: () -> Unit = {}
) {
    var activeEngine by remember {
        mutableStateOf(
            if (projectName.contains("Football", ignoreCase = true) || projectName.contains("Rising", ignoreCase = true)) {
                GameEngineMode.FOOTBALL_3D
            } else {
                GameEngineMode.CANYON_3D
            }
        )
    }

    // Common Game State
    var score by remember { mutableIntStateOf(0) }
    var gameMessage by remember { mutableStateOf<String?>(null) }
    var isGameOver by remember { mutableStateOf(false) }

    // 1. Football 3D State
    var strikerX by remember { mutableFloatStateOf(0f) } // -100f to +100f
    var strikerY by remember { mutableFloatStateOf(0f) } // -50f to +50f
    var ballX by remember { mutableFloatStateOf(0f) }
    var ballY by remember { mutableFloatStateOf(0f) }
    var ballZ by remember { mutableFloatStateOf(0f) } // 0f (near striker) to 300f (at goal line)
    var ballVx by remember { mutableFloatStateOf(0f) }
    var ballVy by remember { mutableFloatStateOf(0f) }
    var ballVz by remember { mutableFloatStateOf(0f) }
    var isBallInFlight by remember { mutableStateOf(false) }
    var goalkeeperX by remember { mutableFloatStateOf(0f) }
    var goalkeeperVx by remember { mutableFloatStateOf(2f) }

    // 2. Canyon 3D State
    var jetX by remember { mutableFloatStateOf(0f) }
    var jetY by remember { mutableFloatStateOf(0f) }
    var canyonRingZ by remember { mutableFloatStateOf(300f) }
    var canyonRingX by remember { mutableFloatStateOf(0f) }

    // 3. Arcade Flight 2D State
    var rocketY by remember { mutableFloatStateOf(200f) }
    var rocketVelocity by remember { mutableFloatStateOf(0f) }
    var gatesX by remember { mutableFloatStateOf(400f) }
    var gateGapY by remember { mutableFloatStateOf(220f) }

    // Game loop ticks
    LaunchedEffect(activeEngine, isGameOver) {
        while (!isGameOver) {
            delay(32) // ~30 FPS

            when (activeEngine) {
                GameEngineMode.FOOTBALL_3D -> {
                    // Goalkeeper AI patrol
                    goalkeeperX += goalkeeperVx
                    if (goalkeeperX > 60f) {
                        goalkeeperX = 60f
                        goalkeeperVx = -Random.nextInt(2, 5).toFloat()
                    } else if (goalkeeperX < -60f) {
                        goalkeeperX = -60f
                        goalkeeperVx = Random.nextInt(2, 5).toFloat()
                    }

                    if (isBallInFlight) {
                        ballX += ballVx
                        ballY += ballVy
                        ballZ += ballVz
                        ballVy += 0.4f // Arc gravity

                        // Ball reached goal line
                        if (ballZ >= 280f) {
                            isBallInFlight = false
                            // Check goal bounds (goal width is approx -70f to +70f)
                            val goalWidth = 65f
                            val keeperCatchDist = 28f
                            val distToKeeper = kotlin.math.abs(ballX - goalkeeperX)

                            if (kotlin.math.abs(ballX) <= goalWidth && ballY <= 60f) {
                                if (distToKeeper < keeperCatchDist) {
                                    gameMessage = "SAVED BY GOALKEEPER! 🧤"
                                } else {
                                    score += 1
                                    gameMessage = "GOOOAL! ⚽🎉 (+1)"
                                }
                            } else {
                                gameMessage = "MISSED WIDE! 🥅"
                            }
                        }
                    }
                }

                GameEngineMode.CANYON_3D -> {
                    canyonRingZ -= 8f
                    if (canyonRingZ < 10f) {
                        canyonRingZ = 300f
                        canyonRingX = Random.nextInt(-80, 80).toFloat()
                        score += 10
                    }
                }

                GameEngineMode.ARCADE_2D -> {
                    rocketVelocity += 0.8f // Gravity
                    rocketY += rocketVelocity

                    gatesX -= 5f
                    if (gatesX < -60f) {
                        gatesX = 360f
                        gateGapY = Random.nextInt(120, 320).toFloat()
                        score += 1
                    }

                    // Collision
                    if (rocketY > 440f || rocketY < 10f) {
                        isGameOver = true
                        gameMessage = "FAILED"
                    }
                    if (gatesX in 60f..140f) {
                        if (rocketY < gateGapY - 45f || rocketY > gateGapY + 45f) {
                            isGameOver = true
                            gameMessage = "FAILED"
                        }
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1015))
            .padding(12.dp)
    ) {
        // Top Engine Mode Selector Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GameEngineMode.values().forEach { mode ->
                val isSelected = activeEngine == mode
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            activeEngine = mode
                            score = 0
                            gameMessage = null
                            isGameOver = false
                            isBallInFlight = false
                            ballX = 0f
                            ballY = 0f
                            ballZ = 0f
                        }
                        .testTag("engine_chip_${mode.name}"),
                    color = if (isSelected) Color(0xFF6C5CE7) else Color(0xFF222534),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = mode.title,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else Color(0xFFA5A9BF),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Header Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Engine Viewport: ${activeEngine.title}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Score: $score | Physics: 60Hz Mobile GPU",
                    fontSize = 11.sp,
                    color = Color(0xFF00E5FF)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Quick Build & Install APK button
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onOpenBuildAndInstall() }
                        .testTag("action_viewport_build_apk"),
                    color = Color(0xFF1B4332)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Android,
                            contentDescription = null,
                            tint = Color(0xFF55EFC4),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Build APK",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF55EFC4)
                        )
                    }
                }

                // Reset Button
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable {
                            score = 0
                            gameMessage = null
                            isGameOver = false
                            isBallInFlight = false
                            ballX = 0f
                            ballY = 0f
                            ballZ = 0f
                            rocketY = 200f
                            rocketVelocity = 0f
                            gatesX = 400f
                        },
                    color = Color(0xFF262340)
                ) {
                    Text(
                        text = "Reset",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF9E86FF),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Game Canvas Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .border(BorderStroke(1.dp, Color(0xFF2A2D40)), RoundedCornerShape(10.dp))
                .testTag("interactive_game_viewport_canvas")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cw = size.width
                val ch = size.height

                when (activeEngine) {
                    GameEngineMode.FOOTBALL_3D -> {
                        // 3D Soccer Pitch & Stadium Rendering
                        val horizonY = ch * 0.28f
                        val goalLineY = ch * 0.35f

                        // Stadium Sky & Crowd
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF1B2A4A), Color(0xFF2B3A67), Color(0xFF3B487A))
                            ),
                            topLeft = Offset(0f, 0f),
                            size = Size(cw, horizonY)
                        )
                        // Stadium Floodlights & Crowd banner
                        drawRect(Color(0xFF101828), topLeft = Offset(0f, horizonY - 24f), size = Size(cw, 24f))
                        for (i in 0..12) {
                            val dotX = cw * (i / 12f)
                            drawCircle(Color(0xFFFFEE88), radius = 3f, center = Offset(dotX, horizonY - 14f))
                        }

                        // 3D Perspective Pitch Ground
                        drawRect(
                            color = Color(0xFF1E5128),
                            topLeft = Offset(0f, horizonY),
                            size = Size(cw, ch - horizonY)
                        )

                        // Grass Stripes with 3D depth
                        val stripeCount = 7
                        for (i in 0 until stripeCount) {
                            val stripeColor = if (i % 2 == 0) Color(0xFF2D6A4F) else Color(0xFF1B4332)
                            val yTop = horizonY + (ch - horizonY) * (i / stripeCount.toFloat())
                            val yBottom = horizonY + (ch - horizonY) * ((i + 1) / stripeCount.toFloat())
                            drawRect(
                                color = stripeColor,
                                topLeft = Offset(0f, yTop),
                                size = Size(cw, yBottom - yTop)
                            )
                        }

                        // Perspective Lines (Touchlines converging to vanishing point at center horizon)
                        val vpX = cw * 0.5f
                        val vpY = horizonY

                        // Outer pitch sidelines
                        drawLine(
                            color = Color(0xAAFFFFFF),
                            start = Offset(cw * 0.15f, goalLineY),
                            end = Offset(cw * 0.02f, ch),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = Color(0xAAFFFFFF),
                            start = Offset(cw * 0.85f, goalLineY),
                            end = Offset(cw * 0.98f, ch),
                            strokeWidth = 3f
                        )
                        // Goal Line
                        drawLine(
                            color = Color(0xDDFFFFFF),
                            start = Offset(cw * 0.15f, goalLineY),
                            end = Offset(cw * 0.85f, goalLineY),
                            strokeWidth = 3f
                        )
                        // Penalty Box
                        val penaltyBoxTop = goalLineY
                        val penaltyBoxBottom = ch * 0.58f
                        drawLine(Color(0xBBFFFFFF), Offset(cw * 0.28f, penaltyBoxTop), Offset(cw * 0.22f, penaltyBoxBottom), 2.5f)
                        drawLine(Color(0xBBFFFFFF), Offset(cw * 0.72f, penaltyBoxTop), Offset(cw * 0.78f, penaltyBoxBottom), 2.5f)
                        drawLine(Color(0xBBFFFFFF), Offset(cw * 0.22f, penaltyBoxBottom), Offset(cw * 0.78f, penaltyBoxBottom), 2.5f)
                        // Penalty spot
                        drawCircle(Color.White, radius = 4f, center = Offset(vpX, ch * 0.50f))

                        // 3D Goal Posts with Net Depth
                        val goalLeftX = cw * 0.32f
                        val goalRightX = cw * 0.68f
                        val postHeight = 65f
                        val netDepth = 22f

                        // Goal Netting Background
                        val netPath = Path().apply {
                            moveTo(goalLeftX, goalLineY)
                            lineTo(goalLeftX, goalLineY - postHeight)
                            lineTo(goalLeftX + netDepth, goalLineY - postHeight - netDepth)
                            lineTo(goalRightX - netDepth, goalLineY - postHeight - netDepth)
                            lineTo(goalRightX, goalLineY - postHeight)
                            lineTo(goalRightX, goalLineY)
                            close()
                        }
                        drawPath(netPath, color = Color(0x33FFFFFF))

                        // Goal Frame (White posts & crossbar)
                        drawLine(Color.White, Offset(goalLeftX, goalLineY), Offset(goalLeftX, goalLineY - postHeight), 6f)
                        drawLine(Color.White, Offset(goalRightX, goalLineY), Offset(goalRightX, goalLineY - postHeight), 6f)
                        drawLine(Color.White, Offset(goalLeftX, goalLineY - postHeight), Offset(goalRightX, goalLineY - postHeight), 6f)

                        // 3D Goalkeeper
                        val gkScreenX = vpX + (goalkeeperX / 100f) * (goalRightX - goalLeftX) * 0.5f
                        val gkScreenY = goalLineY - 14f
                        // Keeper shadow
                        drawOval(Color(0x77000000), topLeft = Offset(gkScreenX - 14f, goalLineY - 4f), size = Size(28f, 8f))
                        // Keeper body (Yellow / Orange kit)
                        drawCircle(Color(0xFFFFD166), radius = 10f, center = Offset(gkScreenX, gkScreenY - 14f))
                        drawRect(Color(0xFFFF6B6B), topLeft = Offset(gkScreenX - 8f, gkScreenY - 10f), size = Size(16f, 16f))
                        // Keeper gloves
                        drawCircle(Color(0xFF00E5FF), radius = 4f, center = Offset(gkScreenX - 12f, gkScreenY - 6f))
                        drawCircle(Color(0xFF00E5FF), radius = 4f, center = Offset(gkScreenX + 12f, gkScreenY - 6f))

                        // 3D Striker Player (Blue & Cyan kit)
                        val strikerScreenX = vpX + (strikerX * 1.5f)
                        val strikerScreenY = ch * 0.78f + strikerY
                        // Striker shadow
                        drawOval(Color(0x77000000), topLeft = Offset(strikerScreenX - 18f, strikerScreenY + 12f), size = Size(36f, 12f))
                        // Striker body
                        drawCircle(Color(0xFFFFDFBA), radius = 12f, center = Offset(strikerScreenX, strikerScreenY - 20f))
                        drawRect(Color(0xFF3A86FF), topLeft = Offset(strikerScreenX - 12f, strikerScreenY - 10f), size = Size(24f, 22f))
                        drawRect(Color(0xFF023E8A), topLeft = Offset(strikerScreenX - 10f, strikerScreenY + 12f), size = Size(9f, 12f))
                        drawRect(Color(0xFF023E8A), topLeft = Offset(strikerScreenX + 1f, strikerScreenY + 12f), size = Size(9f, 12f))

                        // 3D Soccer Ball with perspective scale and shadow
                        val zProgress = (ballZ / 300f).coerceIn(0f, 1f)
                        val ballScale = 1f - (zProgress * 0.55f)
                        val ballRadius = 13f * ballScale

                        val ballScreenX = if (!isBallInFlight) {
                            strikerScreenX + 14f
                        } else {
                            vpX + ballX * (1f - zProgress * 0.3f)
                        }
                        val ballGroundY = strikerScreenY + 16f - (zProgress * (strikerScreenY + 16f - goalLineY))
                        val ballScreenY = ballGroundY - (ballY * ballScale)

                        // Ball Shadow on grass
                        drawOval(
                            color = Color(0x66000000),
                            topLeft = Offset(ballScreenX - ballRadius, ballGroundY - 4f),
                            size = Size(ballRadius * 2, 8f * ballScale)
                        )
                        // Soccer Ball (White sphere + dark pentagon pattern)
                        drawCircle(Color.White, radius = ballRadius, center = Offset(ballScreenX, ballScreenY))
                        drawCircle(Color(0xFF222222), radius = ballRadius * 0.45f, center = Offset(ballScreenX, ballScreenY))
                        drawCircle(Color(0xFF555555), radius = ballRadius * 0.25f, center = Offset(ballScreenX + 2f, ballScreenY - 2f))
                    }

                    GameEngineMode.CANYON_3D -> {
                        // 3D Canyon Flight Sci-Fi Grid
                        val vpX = cw * 0.5f
                        val vpY = ch * 0.45f

                        // Neon Deep Space Sky
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF080614), Color(0xFF1B0B38), Color(0xFF2E0854))
                            ),
                            size = size
                        )

                        // Canyon Walls & Wireframe Grid lines
                        for (i in -5..5) {
                            val xSpread = i * 45f
                            drawLine(
                                color = Color(0x559E86FF),
                                start = Offset(vpX, vpY),
                                end = Offset(vpX + xSpread * 4f, ch),
                                strokeWidth = 1.5f
                            )
                        }
                        // Horizontal depth grid rings
                        for (j in 1..8) {
                            val yRing = vpY + (ch - vpY) * (j / 8f) * (j / 8f)
                            drawLine(
                                color = Color(0x4400E5FF),
                                start = Offset(0f, yRing),
                                end = Offset(cw, yRing),
                                strokeWidth = 1.5f
                            )
                        }

                        // Approaching 3D Canyon Gate Ring
                        val ringProgress = (canyonRingZ / 300f).coerceIn(0.1f, 1f)
                        val ringScale = (1.1f - ringProgress).coerceAtLeast(0.1f)
                        val ringX = vpX + canyonRingX * ringScale
                        val ringY = vpY + (ch - vpY) * 0.5f * ringScale
                        val ringRadius = 60f * ringScale * 2f

                        drawCircle(
                            color = Color(0xFF00E5FF),
                            radius = ringRadius,
                            center = Offset(ringX, ringY),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f * ringScale)
                        )

                        // 3D Jet Fighter (Player)
                        val jetScreenX = vpX + jetX
                        val jetScreenY = ch * 0.75f + jetY
                        val jetPath = Path().apply {
                            moveTo(jetScreenX, jetScreenY - 24f) // Nose
                            lineTo(jetScreenX + 30f, jetScreenY + 16f) // Right wing
                            lineTo(jetScreenX, jetScreenY + 8f) // Tail center
                            lineTo(jetScreenX - 30f, jetScreenY + 16f) // Left wing
                            close()
                        }
                        drawPath(jetPath, color = Color(0xFF6C5CE7))
                        // Thruster flame
                        drawCircle(Color(0xFFFF9F43), radius = 6f, center = Offset(jetScreenX, jetScreenY + 14f))
                    }

                    GameEngineMode.ARCADE_2D -> {
                        // Pixel Mountains & Rocket Flight (Screenshot 12 recreation)
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF6DA4A4), Color(0xFFD49E7C), Color(0xFF4C3B5E))
                            ),
                            size = size
                        )

                        // Mountains
                        val mountainPath = Path().apply {
                            moveTo(0f, ch)
                            lineTo(0f, ch - 120f)
                            lineTo(cw * 0.35f, ch - 240f)
                            lineTo(cw * 0.65f, ch - 150f)
                            lineTo(cw, ch - 210f)
                            lineTo(cw, ch)
                            close()
                        }
                        drawPath(mountainPath, color = Color(0xFF382F4D))

                        // Gates
                        drawRect(Color(0xFF00E5FF), topLeft = Offset(gatesX, 0f), size = Size(24f, gateGapY - 45f))
                        drawRect(Color(0xFF00E5FF), topLeft = Offset(gatesX, gateGapY + 45f), size = Size(24f, ch - (gateGapY + 45f)))

                        // Rocket
                        val rx = 100f
                        val ry = rocketY.coerceIn(10f, ch - 20f)
                        drawCircle(Color.White, radius = 12f, center = Offset(rx, ry))
                        drawCircle(Color(0xFF6C5CE7), radius = 8f, center = Offset(rx - 4f, ry))
                        drawCircle(Color(0xFFFF9100), radius = 5f, center = Offset(rx - 14f, ry))
                    }
                }
            }

            // Message / Score Overlay
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                gameMessage?.let { msg ->
                    Surface(
                        color = Color(0xDD000000),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFF00E5FF))
                    ) {
                        Text(
                            text = msg,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF00E5FF),
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Virtual Touch Controls Pad
        when (activeEngine) {
            GameEngineMode.FOOTBALL_3D -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // D-Pad for player movement
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .clickable {
                                    strikerX = (strikerX - 18f).coerceAtLeast(-90f)
                                }
                                .testTag("ctrl_football_left"),
                            color = Color(0xFF262838)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("◀", color = Color.White, fontSize = 16.sp)
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .clickable {
                                        strikerY = (strikerY - 14f).coerceAtLeast(-40f)
                                    }
                                    .testTag("ctrl_football_up"),
                                color = Color(0xFF262838)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("▲", color = Color.White, fontSize = 16.sp)
                                }
                            }
                            Surface(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .clickable {
                                        strikerY = (strikerY + 14f).coerceAtMost(30f)
                                    }
                                    .testTag("ctrl_football_down"),
                                color = Color(0xFF262838)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("▼", color = Color.White, fontSize = 16.sp)
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .clickable {
                                    strikerX = (strikerX + 18f).coerceAtMost(90f)
                                }
                                .testTag("ctrl_football_right"),
                            color = Color(0xFF262838)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("▶", color = Color.White, fontSize = 16.sp)
                            }
                        }
                    }

                    // Action Buttons (SHOOT ⚽ & DRIBBLE)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (!isBallInFlight) {
                                    isBallInFlight = true
                                    ballZ = 0f
                                    ballX = strikerX
                                    ballY = 0f
                                    // Target toward goal mouth with curve
                                    ballVx = (Random.nextInt(-2, 3) + (strikerX * 0.1f)).toFloat()
                                    ballVy = -6f
                                    ballVz = 16f
                                    gameMessage = "POWER SHOT! ⚽⚡"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE63946)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("btn_football_shoot")
                        ) {
                            Text("SHOOT ⚽", fontWeight = FontWeight.Black, fontSize = 14.sp)
                        }

                        Button(
                            onClick = {
                                if (!isBallInFlight) {
                                    isBallInFlight = true
                                    ballZ = 0f
                                    ballX = strikerX + 10f
                                    ballY = 0f
                                    ballVx = 0f
                                    ballVy = -2f
                                    ballVz = 7f
                                    gameMessage = "Dribble Pass 👟"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF457B9D)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("btn_football_pass")
                        ) {
                            Text("PASS 👟", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            GameEngineMode.CANYON_3D -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { jetX = (jetX - 25f).coerceAtLeast(-120f) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262838))
                        ) {
                            Text("◀ STEER LEFT")
                        }
                        Button(
                            onClick = { jetX = (jetX + 25f).coerceAtMost(120f) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262838))
                        ) {
                            Text("STEER RIGHT ▶")
                        }
                    }

                    Button(
                        onClick = {
                            score += 5
                            canyonRingZ -= 20f
                            gameMessage = "HYPER BOOST! 🚀💨"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7))
                    ) {
                        Text("BOOST ⚡")
                    }
                }
            }

            GameEngineMode.ARCADE_2D -> {
                Button(
                    onClick = {
                        if (isGameOver) {
                            rocketY = 200f
                            rocketVelocity = 0f
                            gatesX = 400f
                            score = 0
                            isGameOver = false
                            gameMessage = null
                        } else {
                            rocketVelocity = -7.5f // Thrust
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A4EB5)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(if (isGameOver) "RETRY FLIGHT 🔄" else "TAP TO THRUST 🚀", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

