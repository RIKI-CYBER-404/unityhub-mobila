package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BuildPlatform
import com.example.data.model.CloudBuildJob
import com.example.data.model.OpenTab
import com.example.data.model.ReleaseChannel
import com.example.data.model.UnityEditorVersion
import com.example.data.model.UnityLicense
import com.example.data.model.UnityProject
import com.example.data.model.UnityTemplate
import com.example.data.model.UnityUser
import com.example.data.model.WorkspaceProject
import com.example.data.repository.UnityRepository
import com.example.data.repository.WorkspaceRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    WORKSPACE_HOME,
    EDITOR_STUDIO,
    NEW_PROJECT,
    PROJECT_SETTINGS,
    HUB_INSTALLS,
    HUB_LICENSES,
    HUB_ACCOUNT
}

class UnityHubViewModel(application: Application) : AndroidViewModel(application) {

    val repository = UnityRepository(application)
    val workspaceRepo = WorkspaceRepository()

    // Screen Navigation
    private val _currentScreen = MutableStateFlow(AppScreen.WORKSPACE_HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Workspace & Editor State
    val workspaceProjects: StateFlow<List<WorkspaceProject>> = workspaceRepo.projects
    val activeWorkspaceProject: StateFlow<WorkspaceProject?> = workspaceRepo.activeProject
    val openTabs: StateFlow<List<OpenTab>> = workspaceRepo.openTabs
    val selectedTabId: StateFlow<String?> = workspaceRepo.selectedTabId
    val activeFileContent: StateFlow<String> = workspaceRepo.activeFileContent

    // Hub State
    val currentUser: StateFlow<UnityUser?> = repository.currentUser
    val licenses: StateFlow<List<UnityLicense>> = repository.licenses
    val editorVersions: StateFlow<List<UnityEditorVersion>> = repository.editorVersions
    val activeBuildJob: StateFlow<CloudBuildJob?> = repository.activeBuildJob
    val templates: List<UnityTemplate> = repository.templates

    // Dialog & Sheet States
    private val _showActivateLicenseDialog = MutableStateFlow(false)
    val showActivateLicenseDialog: StateFlow<Boolean> = _showActivateLicenseDialog.asStateFlow()

    private val _showLoginDialog = MutableStateFlow(false)
    val showLoginDialog: StateFlow<Boolean> = _showLoginDialog.asStateFlow()

    private val _showLocateEditorDialog = MutableStateFlow(false)
    val showLocateEditorDialog: StateFlow<Boolean> = _showLocateEditorDialog.asStateFlow()

    private val _selectedEditorForModules = MutableStateFlow<UnityEditorVersion?>(null)
    val selectedEditorForModules: StateFlow<UnityEditorVersion?> = _selectedEditorForModules.asStateFlow()

    // Theme Mode (Dark / Light)
    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
        emitMessage("Switched to ${if (_isDarkTheme.value) "Dark" else "Light"} Theme")
    }

    // Build, Run & Install Dialog
    private val _showBuildInstallDialog = MutableStateFlow(false)
    val showBuildInstallDialog: StateFlow<Boolean> = _showBuildInstallDialog.asStateFlow()

    fun openBuildInstallDialog() { _showBuildInstallDialog.value = true }
    fun closeBuildInstallDialog() { _showBuildInstallDialog.value = false }

    // Feedback Snackbar Flow
    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    // Workspace Actions
    fun openWorkspace(project: WorkspaceProject) {
        workspaceRepo.openProject(project)
        _currentScreen.value = AppScreen.EDITOR_STUDIO
        emitMessage("Opened workspace '${project.name}'")
    }

    fun closeWorkspace() {
        workspaceRepo.closeActiveProject()
        _currentScreen.value = AppScreen.WORKSPACE_HOME
    }

    fun createWorkspaceProject(name: String, pkgName: String, location: String, templateTitle: String) {
        val proj = workspaceRepo.createProject(name, pkgName, location, templateTitle)
        _currentScreen.value = AppScreen.EDITOR_STUDIO
        emitMessage("Created and opened project '${proj.name}'")
    }

    fun openFile(filePath: String, fileName: String, isScene: Boolean) {
        workspaceRepo.openFile(filePath, fileName, isScene)
    }

    fun closeTab(tabId: String) {
        workspaceRepo.closeTab(tabId)
    }

    fun selectTab(tabId: String) {
        workspaceRepo.selectTab(tabId)
    }

    fun updateActiveFileContent(newContent: String) {
        workspaceRepo.updateActiveFileContent(newContent)
    }

    fun saveActiveFile() {
        workspaceRepo.saveActiveFile()
        emitMessage("File saved successfully.")
    }

    fun createNewFileInWorkspace(parentPath: String, fileName: String, isDir: Boolean) {
        workspaceRepo.createNewFile(parentPath, fileName, isDir)
        emitMessage("Created ${if (isDir) "folder" else "file"} '$fileName'")
    }

    fun updateProjectPlatform(platform: BuildPlatform) {
        workspaceRepo.updateProjectPlatform(platform)
        emitMessage("Switched active build platform to ${platform.displayName}")
    }

    fun updateCompanyName(name: String) {
        workspaceRepo.updateCompanyName(name)
    }

    fun triggerApkBuild() {
        val projName = activeWorkspaceProject.value?.name ?: "Game"
        repository.triggerCloudBuild("proj_active")
        emitMessage("Compiling and packaging $projName APK...")
    }

    // Hub Dialog controls
    fun openActivateLicenseDialog() { _showActivateLicenseDialog.value = true }
    fun closeActivateLicenseDialog() { _showActivateLicenseDialog.value = false }

    fun openLoginDialog() { _showLoginDialog.value = true }
    fun closeLoginDialog() { _showLoginDialog.value = false }

    fun openLocateEditorDialog() { _showLocateEditorDialog.value = true }
    fun closeLocateEditorDialog() { _showLocateEditorDialog.value = false }

    fun selectEditorForModules(editor: UnityEditorVersion?) {
        _selectedEditorForModules.value = editor
    }

    fun dismissCloudBuild() {
        repository.dismissBuildJob()
    }

    fun installVersion(versionClean: String) {
        repository.installEditorVersion(versionClean)
        emitMessage("Starting installation for Unity $versionClean...")
    }

    fun toggleModule(cleanVersion: String, moduleId: String) {
        repository.toggleModule(cleanVersion, moduleId)
    }

    fun locateEditor(cleanVersion: String, path: String) {
        repository.locateInstalledEditor(cleanVersion, path)
        _showLocateEditorDialog.value = false
        emitMessage("Unity $cleanVersion linked from storage.")
    }

    fun activatePersonalLicense(revenueCondition: String) {
        repository.activatePersonalLicense(revenueCondition) { success, msg ->
            emitMessage(msg)
            if (success) _showActivateLicenseDialog.value = false
        }
    }

    fun activateSerialLicense(serialKey: String) {
        repository.activateSerialLicense(serialKey) { success, msg ->
            emitMessage(msg)
            if (success) _showActivateLicenseDialog.value = false
        }
    }

    fun returnLicense(licenseId: String) {
        repository.returnLicense(licenseId) { _, msg ->
            emitMessage(msg)
        }
    }

    fun loginWithOAuth(code: String) {
        repository.loginWithOAuthCode(code) { success, error ->
            if (success) {
                _showLoginDialog.value = false
                emitMessage("Welcome back to Unity Hub!")
            } else {
                emitMessage(error ?: "Login failed.")
            }
        }
    }

    fun loginWithToken(email: String, token: String, displayName: String) {
        repository.loginWithDirectToken(email, token, displayName) { success, error ->
            if (success) {
                _showLoginDialog.value = false
                emitMessage("Unity ID authorized via Personal Access Token.")
            } else {
                emitMessage(error ?: "Failed to authenticate token.")
            }
        }
    }

    fun createUnityAccount(name: String, email: String, username: String, orgName: String) {
        repository.loginWithDirectToken(
            email = email,
            token = "upat_new_${System.currentTimeMillis()}",
            displayName = name.ifBlank { username }
        ) { success, error ->
            if (success) {
                _showLoginDialog.value = false
                emitMessage("Unity ID Account created successfully! Welcome, ${name.ifBlank { username }}")
                repository.activatePersonalLicense("I don't use Unity in a professional capacity") { _, _ -> }
            } else {
                emitMessage(error ?: "Failed to create account.")
            }
        }
    }

    fun loginDemo() {
        repository.loginWithDemo()
        _showLoginDialog.value = false
        emitMessage("Logged in with Unity Developer account.")
    }

    fun logout() {
        repository.logout()
        emitMessage("Logged out of Unity ID.")
    }

    private fun emitMessage(msg: String) {
        viewModelScope.launch {
            _snackbarMessage.emit(msg)
        }
    }
}
