package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UnityLicense
import com.example.ui.components.UnityLicenseCard
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityDarkBackground
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@Composable
fun LicensesScreen(
    licenses: List<UnityLicense>,
    onActivateLicenseClick: () -> Unit,
    onReturnLicense: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(UnityDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("licenses_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Header Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Unity Licenses",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = UnityTextPrimary
                    )
                    Text(
                        text = "Official seat allocations & cloud entitlements",
                        fontSize = 12.sp,
                        color = UnityTextSecondary
                    )
                }

                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onActivateLicenseClick() }
                        .testTag("btn_activate_new_license"),
                    color = UnityCyan,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Activate",
                            tint = Color(0xFF00363D),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Activate",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00363D)
                        )
                    }
                }
            }
        }

        // Hardware Keystore Security Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14242B)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, UnityCyan.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Encrypted",
                        tint = UnityCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Hardware KeyStore Bound (AES-256 GCM)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                        Text(
                            text = "License serials & OAuth tokens are encrypted using Android Keystore master keys and stored securely on this device.",
                            fontSize = 11.sp,
                            color = UnityTextSecondary,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // Licenses List
        if (licenses.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "No Active Licenses Found", fontWeight = FontWeight.Bold, color = UnityTextPrimary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Activate your Free Personal License or enter your Pro serial key to begin building games.",
                            fontSize = 12.sp,
                            color = UnityTextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onActivateLicenseClick,
                            colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D))
                        ) {
                            Text("Activate License Now")
                        }
                    }
                }
            }
        } else {
            items(licenses, key = { it.id }) { license ->
                UnityLicenseCard(
                    license = license,
                    onReturnLicense = { onReturnLicense(license.id) }
                )
            }
        }

        // Official License Policy Guide
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, UnityCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = UnityTextSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Unity License Tier Guidelines",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Unity Personal: Free for creators and small studios with under \$100,000 USD gross annual revenue or funding.\n" +
                                "• Unity Pro: For commercial studios requiring full source code access, Havok physics, cloud diagnostics, and splash screen removal.\n" +
                                "• Returning Seats: You can release your active machine license when migrating workstations or reinstalling.",
                        fontSize = 11.sp,
                        color = UnityTextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
