package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.WorkspaceProject
import com.example.ui.components.ActivateLicenseDialog
import com.example.ui.components.AddModulesDialog
import com.example.ui.components.BuildAndInstallDialog
import com.example.ui.components.CloudBuildDialog
import com.example.ui.components.LocateEditorDialog
import com.example.ui.components.UnityLoginDialog
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.EditorStudioScreen
import com.example.ui.screens.InstallsScreen
import com.example.ui.screens.LicensesScreen
import com.example.ui.screens.NewProjectScreen
import com.example.ui.screens.ProjectSettingsScreen
import com.example.ui.screens.WorkspaceHomeScreen
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@Composable
fun SuperUnityHubApp(
    viewModel: UnityHubViewModel
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val workspaceProjects by viewModel.workspaceProjects.collectAsStateWithLifecycle()
    val activeWorkspaceProject by viewModel.activeWorkspaceProject.collectAsStateWithLifecycle()
    val openTabs by viewModel.openTabs.collectAsStateWithLifecycle()
    val selectedTabId by viewModel.selectedTabId.collectAsStateWithLifecycle()
    val activeFileContent by viewModel.activeFileContent.collectAsStateWithLifecycle()

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val licenses by viewModel.licenses.collectAsStateWithLifecycle()
    val editorVersions by viewModel.editorVersions.collectAsStateWithLifecycle()
    val activeBuildJob by viewModel.activeBuildJob.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

    val showActivateLicenseDialog by viewModel.showActivateLicenseDialog.collectAsStateWithLifecycle()
    val showLoginDialog by viewModel.showLoginDialog.collectAsStateWithLifecycle()
    val showLocateEditorDialog by viewModel.showLocateEditorDialog.collectAsStateWithLifecycle()
    val selectedEditorForModules by viewModel.selectedEditorForModules.collectAsStateWithLifecycle()
    val showBuildInstallDialog by viewModel.showBuildInstallDialog.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Hardware Back Navigation
    BackHandler(enabled = currentScreen != AppScreen.WORKSPACE_HOME) {
        when (currentScreen) {
            AppScreen.EDITOR_STUDIO -> viewModel.closeWorkspace()
            AppScreen.NEW_PROJECT -> viewModel.navigateTo(AppScreen.WORKSPACE_HOME)
            AppScreen.PROJECT_SETTINGS -> viewModel.navigateTo(AppScreen.EDITOR_STUDIO)
            AppScreen.HUB_INSTALLS, AppScreen.HUB_LICENSES, AppScreen.HUB_ACCOUNT -> viewModel.navigateTo(AppScreen.WORKSPACE_HOME)
            AppScreen.WORKSPACE_HOME -> { }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = currentScreen != AppScreen.EDITOR_STUDIO, // Drawer in Editor handled inside its own panel
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFF141620),
                modifier = Modifier.width(290.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp)
                ) {
                    // Branding Header
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF262838)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("U", color = Color(0xFF00E5FF), fontWeight = FontWeight.Black, fontSize = 20.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("SUPER UNITY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E5FF), letterSpacing = 1.sp)
                            Text("Mobile Studio", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                    HorizontalDivider(color = Color(0xFF272A3B))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Drawer Items
                    DrawerMenuItem(
                        icon = Icons.Default.Home,
                        title = "Home Workspaces",
                        isSelected = currentScreen == AppScreen.WORKSPACE_HOME,
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(AppScreen.WORKSPACE_HOME)
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DrawerMenuItem(
                        icon = Icons.Default.Code,
                        title = "Editor Studio",
                        isSelected = currentScreen == AppScreen.EDITOR_STUDIO,
                        onClick = {
                            scope.launch { drawerState.close() }
                            if (activeWorkspaceProject == null && workspaceProjects.isNotEmpty()) {
                                viewModel.openWorkspace(workspaceProjects.first())
                            } else {
                                viewModel.navigateTo(AppScreen.EDITOR_STUDIO)
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DrawerMenuItem(
                        icon = Icons.Default.Build,
                        title = "Unity Installs",
                        isSelected = currentScreen == AppScreen.HUB_INSTALLS,
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(AppScreen.HUB_INSTALLS)
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DrawerMenuItem(
                        icon = Icons.Default.Shield,
                        title = "Unity Licenses",
                        isSelected = currentScreen == AppScreen.HUB_LICENSES,
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(AppScreen.HUB_LICENSES)
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DrawerMenuItem(
                        icon = Icons.Default.AccountCircle,
                        title = "Unity ID Account",
                        isSelected = currentScreen == AppScreen.HUB_ACCOUNT,
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(AppScreen.HUB_ACCOUNT)
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DrawerMenuItem(
                        icon = Icons.Default.Android,
                        title = "Android Build & Export",
                        isSelected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.openBuildInstallDialog()
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DrawerMenuItem(
                        icon = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                        title = if (isDarkTheme) "Theme: Dark Mode" else "Theme: Light Mode",
                        isSelected = false,
                        onClick = {
                            viewModel.toggleTheme()
                        }
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // Version footer
                    Text(
                        text = "Super Unity Hub v2.4.0 (Engine 6000.0 LTS)",
                        fontSize = 10.sp,
                        color = Color(0xFF6B7085)
                    )
                }
            }
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color(0xFF0F1015),
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "screen_nav"
                ) { screen ->
                    when (screen) {
                        AppScreen.WORKSPACE_HOME -> {
                            WorkspaceHomeScreen(
                                projects = workspaceProjects,
                                onOpenProject = { viewModel.openWorkspace(it) },
                                onNavigateNewProject = { viewModel.navigateTo(AppScreen.NEW_PROJECT) },
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                isDarkTheme = isDarkTheme,
                                onToggleTheme = { viewModel.toggleTheme() },
                                onOpenBuildAndInstall = { viewModel.openBuildInstallDialog() }
                            )
                        }
                        AppScreen.NEW_PROJECT -> {
                            NewProjectScreen(
                                onNavigateBack = { viewModel.navigateTo(AppScreen.WORKSPACE_HOME) },
                                onCreateProject = { name, pkgName, location, templateTitle ->
                                    viewModel.createWorkspaceProject(name, pkgName, location, templateTitle)
                                }
                            )
                        }
                        AppScreen.PROJECT_SETTINGS -> {
                            activeWorkspaceProject?.let { proj ->
                                ProjectSettingsScreen(
                                    project = proj,
                                    onNavigateBack = { viewModel.navigateTo(AppScreen.EDITOR_STUDIO) },
                                    onPlatformChanged = { viewModel.updateProjectPlatform(it) },
                                    onCompanyNameChanged = { viewModel.updateCompanyName(it) }
                                )
                            } ?: run {
                                viewModel.navigateTo(AppScreen.WORKSPACE_HOME)
                            }
                        }
                        AppScreen.EDITOR_STUDIO -> {
                            activeWorkspaceProject?.let { proj ->
                                EditorStudioScreen(
                                    project = proj,
                                    openTabs = openTabs,
                                    selectedTabId = selectedTabId,
                                    activeFileContent = activeFileContent,
                                    onTabSelected = { viewModel.selectTab(it) },
                                    onTabClosed = { viewModel.closeTab(it) },
                                    onFileContentChanged = { viewModel.updateActiveFileContent(it) },
                                    onSaveFile = { viewModel.saveActiveFile() },
                                    onOpenFile = { path, name, isScene -> viewModel.openFile(path, name, isScene) },
                                    onCreateNewFile = { parent, name, isDir -> viewModel.createNewFileInWorkspace(parent, name, isDir) },
                                    onNavigateProjectSettings = { viewModel.navigateTo(AppScreen.PROJECT_SETTINGS) },
                                    onNavigateBackToHome = { viewModel.closeWorkspace() },
                                    onTriggerBuild = { viewModel.triggerApkBuild() },
                                    isDarkTheme = isDarkTheme,
                                    onToggleTheme = { viewModel.toggleTheme() },
                                    onOpenBuildAndInstall = { viewModel.openBuildInstallDialog() }
                                )
                            } ?: run {
                                viewModel.navigateTo(AppScreen.WORKSPACE_HOME)
                            }
                        }
                        AppScreen.HUB_INSTALLS -> {
                            InstallsScreen(
                                editorVersions = editorVersions,
                                onAddModules = { viewModel.selectEditorForModules(it) },
                                onInstall = { viewModel.installVersion(it) },
                                onLocateEditorClick = { viewModel.openLocateEditorDialog() }
                            )
                        }
                        AppScreen.HUB_LICENSES -> {
                            LicensesScreen(
                                licenses = licenses,
                                onActivateLicenseClick = { viewModel.openActivateLicenseDialog() },
                                onReturnLicense = { viewModel.returnLicense(it) }
                            )
                        }
                        AppScreen.HUB_ACCOUNT -> {
                            AccountScreen(
                                currentUser = currentUser,
                                onLoginClick = { viewModel.openLoginDialog() },
                                onLogoutClick = { viewModel.logout() },
                                onDemoLoginClick = { viewModel.loginDemo() }
                            )
                        }
                    }
                }
            }
        }
    }

    // Global Modal Dialogs

    if (showActivateLicenseDialog) {
        ActivateLicenseDialog(
            onDismiss = { viewModel.closeActivateLicenseDialog() },
            onActivatePersonal = { cond -> viewModel.activatePersonalLicense(cond) },
            onActivateSerial = { serial -> viewModel.activateSerialLicense(serial) }
        )
    }

    if (showLoginDialog) {
        UnityLoginDialog(
            onDismiss = { viewModel.closeLoginDialog() },
            onOAuthLogin = { code -> viewModel.loginWithOAuth(code) },
            onTokenLogin = { email, token, name -> viewModel.loginWithToken(email, token, name) },
            onDemoLogin = { viewModel.loginDemo() },
            onCreateAccount = { name, email, user, org -> viewModel.createUnityAccount(name, email, user, org) }
        )
    }

    if (showLocateEditorDialog) {
        LocateEditorDialog(
            onDismiss = { viewModel.closeLocateEditorDialog() },
            onLocate = { ver, path -> viewModel.locateEditor(ver, path) }
        )
    }

    selectedEditorForModules?.let { editor ->
        AddModulesDialog(
            editor = editor,
            onDismiss = { viewModel.selectEditorForModules(null) },
            onToggleModule = { modId -> viewModel.toggleModule(editor.cleanVersion, modId) }
        )
    }

    activeBuildJob?.let { job ->
        CloudBuildDialog(
            buildJob = job,
            onDismiss = { viewModel.dismissCloudBuild() }
        )
    }

    if (showBuildInstallDialog) {
        val proj = activeWorkspaceProject ?: workspaceProjects.firstOrNull()
        if (proj != null) {
            BuildAndInstallDialog(
                project = proj,
                onDismiss = { viewModel.closeBuildInstallDialog() }
            )
        }
    }
}

@Composable
private fun DrawerMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag("drawer_item_$title"),
        color = if (isSelected) Color(0xFF38325E) else Color.Transparent,
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color(0xFF9E86FF) else Color(0xFFA5A9BF),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFFD4D7E5)
            )
        }
    }
}
