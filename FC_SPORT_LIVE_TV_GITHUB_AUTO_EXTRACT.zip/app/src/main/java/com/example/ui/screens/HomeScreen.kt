package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BuildPlatform
import com.example.data.model.LicenseStatus
import com.example.data.model.UnityEditorVersion
import com.example.data.model.UnityLicense
import com.example.data.model.UnityProject
import com.example.data.model.UnityUser
import com.example.ui.components.UnityProjectCard
import com.example.ui.theme.UnityAmber
import com.example.ui.theme.UnityCardBackground
import com.example.ui.theme.UnityCardBorder
import com.example.ui.theme.UnityCyan
import com.example.ui.theme.UnityDarkBackground
import com.example.ui.theme.UnityElectricBlue
import com.example.ui.theme.UnityGreen
import com.example.ui.theme.UnityTeal
import com.example.ui.theme.UnityTextMuted
import com.example.ui.theme.UnityTextPrimary
import com.example.ui.theme.UnityTextSecondary

@Composable
fun HomeScreen(
    currentUser: UnityUser?,
    activeLicense: UnityLicense?,
    projects: List<UnityProject>,
    installedEditors: List<UnityEditorVersion>,
    onCreateProjectClick: () -> Unit,
    onActivateLicenseClick: () -> Unit,
    onProjectClick: (UnityProject) -> Unit,
    onLaunchProject: (UnityProject) -> Unit,
    onCloudBuildProject: (UnityProject) -> Unit,
    onNavigateProjects: () -> Unit,
    onNavigateInstalls: () -> Unit,
    modifier: Modifier = Modifier
) {
    val recentProjects = projects.take(2)
    val latestProject = projects.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(UnityDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("home_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Hero Greeting Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_hero_card"),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, UnityCardBorder),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF16252E),
                                    Color(0xFF1B1D25),
                                    Color(0xFF14151B)
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (currentUser != null) "Welcome, ${currentUser.displayName}" else "Super Unity Hub",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = UnityTextPrimary
                                )
                                Text(
                                    text = if (currentUser != null) "${currentUser.role} • ${currentUser.organizationName}" else "Mobile Game Development Suite",
                                    fontSize = 12.sp,
                                    color = UnityCyan
                                )
                            }

                            // Quick New Project FAB
                            Surface(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable { onCreateProjectClick() }
                                    .testTag("home_btn_quick_new_project"),
                                color = UnityCyan,
                                shape = CircleShape
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "New",
                                        tint = Color(0xFF00363D),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "New",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF00363D)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quick Stats Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatBox(
                                title = "Projects",
                                value = "${projects.size}",
                                icon = Icons.Default.Folder,
                                color = UnityCyan,
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                title = "Installs",
                                value = "${installedEditors.size}",
                                icon = Icons.Default.Build,
                                color = UnityElectricBlue,
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                title = "License",
                                value = if (activeLicense != null) "Active" else "None",
                                icon = Icons.Default.Shield,
                                color = if (activeLicense != null) UnityGreen else UnityAmber,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Active License Quick Glance or Activation Reminder
        item {
            if (activeLicense != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, UnityCyan.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF004D5A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VpnKey,
                                    contentDescription = null,
                                    tint = UnityCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = activeLicense.type.displayName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = UnityTextPrimary
                                )
                                Text(
                                    text = "Serial: ${activeLicense.serialNumberMasked}",
                                    fontSize = 11.sp,
                                    color = UnityTextSecondary
                                )
                            }
                        }

                        Surface(
                            color = Color(0xFF163828),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Licensed",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = UnityGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C2218)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, UnityAmber.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "No Active License Detected",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = UnityTextPrimary
                            )
                            Text(
                                text = "Activate Unity Personal for free or enter your Pro key.",
                                fontSize = 11.sp,
                                color = UnityTextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onActivateLicenseClick,
                            colors = ButtonDefaults.buttonColors(containerColor = UnityAmber, contentColor = Color(0xFF331F00)),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(text = "Activate", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section: Recent Projects
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENT PROJECTS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = UnityCyan,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "View All (${projects.size})",
                    fontSize = 12.sp,
                    color = UnityTextSecondary,
                    modifier = Modifier.clickable { onNavigateProjects() }
                )
            }
        }

        if (recentProjects.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "No projects yet", color = UnityTextSecondary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onCreateProjectClick,
                            colors = ButtonDefaults.buttonColors(containerColor = UnityCyan, contentColor = Color(0xFF00363D))
                        ) {
                            Text("Create First Project")
                        }
                    }
                }
            }
        } else {
            items(recentProjects) { project ->
                UnityProjectCard(
                    project = project,
                    onProjectClick = { onProjectClick(project) },
                    onLaunchClick = { onLaunchProject(project) },
                    onCloudBuildClick = { onCloudBuildProject(project) },
                    onSwitchPlatform = { },
                    onDeleteClick = { }
                )
            }
        }

        // Unity Ecosystem Updates & Highlights
        item {
            Text(
                text = "COMMUNITY & RELEASES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = UnityCyan,
                letterSpacing = 1.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = UnityCardBackground),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, UnityCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = Color(0xFF004D5A),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "LTS UPDATE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = UnityCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Unity 6 (6000.0 LTS) Now Generally Available",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = UnityTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Experience up to 4x faster CPU rendering dispatch with Resident Drawer and native Vulkan mobile ray-tracing optimizations.",
                        fontSize = 12.sp,
                        color = UnityTextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
private fun StatBox(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color(0xFF1E2129),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, Color(0xFF2B2F3A))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = UnityTextPrimary)
            Text(text = title, fontSize = 10.sp, color = UnityTextSecondary)
        }
    }
}
