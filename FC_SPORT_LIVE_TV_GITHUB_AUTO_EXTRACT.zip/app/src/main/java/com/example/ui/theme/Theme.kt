package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val UnityColorScheme = darkColorScheme(
    primary = UnityAmber,
    onPrimary = UnityDarkBackground,
    secondary = UnityElectricBlue,
    onSecondary = UnityDarkBackground,
    tertiary = UnityCyan,
    background = UnityDarkBackground,
    onBackground = UnityTextPrimary,
    surface = UnityDarkSurface,
    onSurface = UnityTextPrimary,
    surfaceVariant = UnitySurfaceVariant,
    onSurfaceVariant = UnityTextSecondary,
    error = UnityRed
)

@Composable
fun UnityHubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = UnityColorScheme,
        typography = Typography,
        content = content
    )
}
